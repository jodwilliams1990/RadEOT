from subprocess import check_output
def get_pid(name):
    print(str(check_output(["pidof", name]))[2:-3])
    return check_output(["pidof", name])

#a = get_pid("python3")
import os
'''
c=str(check_output('netstat -tupln | grep 5006', shell=True)).split()
d=['/python']
e=[s for s in c if any(xs in s for xs in d)][0].split('/')[0]
print(e)
killstring='kill -9 ' + e
os.system('netstat -tupln')
os.system(killstring)
os.system('netstat -tupln')
'''

#a=str(check_output('ps -eaf | grep python3', shell=True))
#if "flash" in a:
#    print("open")
    
pidline=str(check_output('ps -eaf | grep dump1090', shell=True)).split()
killstring='kill -9 ' + pidline[1]
os.system(killstring)  
#pidline=str(check_output('ps -eaf | grep bokeh', shell=True)).split()
#print(pidline)
#killstring='kill -9 ' + pidline[1]
#os.system(killstring) 