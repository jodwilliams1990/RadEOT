from subprocess import check_output
import os
import datetime

while "flash" in str(check_output('ps -eaf | grep chromium-b', shell=True)):
    pass
pidline=str(check_output('ps -eaf | grep dump1090', shell=True)).split()
killstring='kill -9 ' + pidline[1]
os.system(killstring)
c=str(check_output('netstat -tupln | grep 5006', shell=True)).split()
d=['/python']
e=[s for s in c if any(xs in s for xs in d)][0].split('/')[0]
killstring='kill -9 ' + e
os.system('netstat -tupln')
os.system(killstring)
timenow=datetime.datetime.now()
radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
logstring=tn+" Stopped Flight Tracking\n"
radeotlog.write(logstring)
radeotlog.close()
