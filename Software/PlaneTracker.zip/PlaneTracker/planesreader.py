import sys
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

lepddir='planes.h5'       #FILE TO LOAD IF NOT CREATING A NEW FILE

reader=pd.read_hdf(lepddir)
print(reader)
planes=reader.addr.unique()
print(planes)

planeselect=0
readerplane=reader.loc[reader['addr']=='ABB775']
readerplane=readerplane.loc[readerplane['dateandtime'] == '2020-02-25 22:04:09.023490']

planespeed=readerplane['speed']

print(planespeed)
'''
plt.plot(readerplane['dateandtime'], readerplane['lat'])
plt.title(planes[planeselect])
plt.show()
'''
