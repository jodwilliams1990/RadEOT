# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'KSWindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_KSWindow(object):
    def setupUi(self, KSWindow):
        KSWindow.setObjectName("KSWindow")
        KSWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(KSWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.TextKS = QtWidgets.QLabel(self.centralwidget)
        self.TextKS.setObjectName("TextKS")
        self.horizontalLayout.addWidget(self.TextKS)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem3)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        spacerItem4 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem4)
        self.SelectKS = QtWidgets.QComboBox(self.centralwidget)
        self.SelectKS.setObjectName("SelectKS")
        self.horizontalLayout_3.addWidget(self.SelectKS)
        self.EnterKS = QtWidgets.QPushButton(self.centralwidget)
        self.EnterKS.setObjectName("EnterKS")
        self.horizontalLayout_3.addWidget(self.EnterKS)
        spacerItem5 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem5)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4.addLayout(self.verticalLayout)
        spacerItem6 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem6)
        self.verticalLayout_2.addLayout(self.horizontalLayout_4)
        self.verticalLayout_3.addLayout(self.verticalLayout_2)
        spacerItem7 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem7)
        KSWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(KSWindow)
        self.statusbar.setObjectName("statusbar")
        KSWindow.setStatusBar(self.statusbar)
        self.menubar = QtWidgets.QMenuBar(KSWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        KSWindow.setMenuBar(self.menubar)
        self.actionChange_Activity = QtWidgets.QAction(KSWindow)
        self.actionChange_Activity.setObjectName("actionChange_Activity")
        self.actionQuit_RadEOT = QtWidgets.QAction(KSWindow)
        self.actionQuit_RadEOT.setObjectName("actionQuit_RadEOT")

        self.retranslateUi(KSWindow)
        QtCore.QMetaObject.connectSlotsByName(KSWindow)

    def retranslateUi(self, KSWindow):
        _translate = QtCore.QCoreApplication.translate
        KSWindow.setWindowTitle(_translate("KSWindow", "MainWindow"))
        self.TextKS.setText(_translate("KSWindow", "  So we can tailor your RadEOT experience, please enter your age    "))
        self.EnterKS.setText(_translate("KSWindow", "[ Submit ]"))
        self.actionChange_Activity.setText(_translate("KSWindow", "Change Activity"))
        self.actionQuit_RadEOT.setText(_translate("KSWindow", "Quit RadEOT"))
