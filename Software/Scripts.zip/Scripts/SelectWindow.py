# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'radeotSelectWindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_SelectWindow(object):
    def setupUi(self, SelectWindow):
        SelectWindow.setObjectName("SelectWindow")
        SelectWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(SelectWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.ActivityGroupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.ActivityGroupBox.setGeometry(QtCore.QRect(40, 490, 721, 63))
        self.ActivityGroupBox.setObjectName("ActivityGroupBox")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.ActivityGroupBox)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.Activity1 = QtWidgets.QPushButton(self.ActivityGroupBox)
        self.Activity1.setObjectName("Activity1")
        self.horizontalLayout.addWidget(self.Activity1)
        self.Activity2 = QtWidgets.QPushButton(self.ActivityGroupBox)
        self.Activity2.setObjectName("Activity2")
        self.horizontalLayout.addWidget(self.Activity2)
        self.Activity3 = QtWidgets.QPushButton(self.ActivityGroupBox)
        self.Activity3.setObjectName("Activity3")
        self.horizontalLayout.addWidget(self.Activity3)
        self.Activity4 = QtWidgets.QPushButton(self.ActivityGroupBox)
        self.Activity4.setObjectName("Activity4")
        self.horizontalLayout.addWidget(self.Activity4)
        self.Activity5 = QtWidgets.QPushButton(self.ActivityGroupBox)
        self.Activity5.setObjectName("Activity5")
        self.horizontalLayout.addWidget(self.Activity5)
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(30, 60, 1211, 401))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setObjectName("label")
        SelectWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(SelectWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        SelectWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(SelectWindow)
        self.statusbar.setObjectName("statusbar")
        SelectWindow.setStatusBar(self.statusbar)

        self.retranslateUi(SelectWindow)
        QtCore.QMetaObject.connectSlotsByName(SelectWindow)

    def retranslateUi(self, SelectWindow):
        _translate = QtCore.QCoreApplication.translate
        SelectWindow.setWindowTitle(_translate("SelectWindow", "SelectWindow"))
        self.ActivityGroupBox.setTitle(_translate("SelectWindow", "GroupBox"))
        self.Activity1.setText(_translate("SelectWindow", "PushButton"))
        self.Activity2.setText(_translate("SelectWindow", "PushButton"))
        self.Activity3.setText(_translate("SelectWindow", "PushButton"))
        self.Activity4.setText(_translate("SelectWindow", "PushButton"))
        self.Activity5.setText(_translate("SelectWindow", "PushButton"))
        self.label.setText(_translate("SelectWindow", "TextLabel"))
