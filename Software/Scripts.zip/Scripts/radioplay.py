import subprocess
import os
import time

f=open("/home/pi/Documents/Scripts/rpconf.txt", "r")
timer=str(f.readline())[:-1]
radiostat=str(f.readline())
print("Playing ", radiostat, "for ", timer, "ms")
radarg='rtl_fm -f ' + radiostat + ' -s 200000 -g 50 | aplay -t raw -r 200000 -f S16_LE &'
procrp=subprocess.Popen([radarg], shell=True)
timea=float(timer)/1000
while timea>0:
    print(timea)
    time.sleep(1)
    timea=timea-1
os.system('pkill rtl_fm')

#radarg=['rtl_fm', '-f ' + radiostat,  ' -s 44100', '-g 50', '|', 'aplay', '-t raw', '-r 44100', '-f S16_LE']#, &']
#procrp=subprocess.Popen([radarg], shell=True)
#radarg='rtl_fm -f ' + radiostat + ' -s 44100 -g 50 | aplay -t raw -r 44100 -f S16_LE &'
#radarg='rtl_fm -M wbfm -f ' + radiostat + ' | aplay -t raw -r 44100 -f S16_LE &'

#procrp=subprocess.Popen([radarg], shell=True)
#time.sleep(timer/1000)
#os.system('pkill rtl_fm')

'''
timea=timer/1000
while timea>0:
    print(timea)
    time.sleep(1)
    timea=timea-1
#time.sleep(timer/1000)
chrcheck.terminate()
os.system('pkill rtl_fm')
'''
#timeout', str(timer/(1000)), 's', 
#radio_play = 'rtl_fm -f' + str(freq) + 'M -s 44100 -g 50 -l 0 - | aplay -t raw -r 44100 -c 1 -f S16_LE'
#radio_play = 'rtl_fm -f' + str(freq) + 'M -s 200000 -g 1000000 | aplay -f S16_LE'
## Sample rate set to 48k - not required ##
# radio_play = 'rtl_fm -f' + str(freq) + ' -s 200000 -r 48000 -g 1000000 | aplay -r 48000 -f S16_LE'        
'''
radio_play = 'timeout ' + str(timer/(1000)) +'s rtl_fm -f' + str(freq) + 'M -s 44100 -g 50 -l 0 - | aplay -t raw -r 44100 -c 1 -f S16_LE'
os.system(radio_play)


if timer == "":
    QtWidgets.QMessageBox.warning(self, 'Error', 'Please enter a listen time.')
else:radio_stop = 'usleep ' + str(timer) + '; pkill rtl_fm'
print ("radio_stop")                
os.system(radio_stop)
'''
