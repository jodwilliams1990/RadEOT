import sqlite3
import pandas as pd

#Name of Excel xlsx file. SQLite database will have the same name and extension .db
f=open("/home/pi/Documents/Scripts/db/dbconf.txt", "r")
xlfile=str(f.readline())
filename="question" 
con=sqlite3.connect('question.db')
#wb=pd.read_excel('RadeotQuestions.xlsx', sheet_name=None)
wb=pd.read_excel(xlfile, sheet_name=None)
for sheet in wb:
    wb[sheet].to_sql(sheet,con, index=False)
con.commit()
con.close()