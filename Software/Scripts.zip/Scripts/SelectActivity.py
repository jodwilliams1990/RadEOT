# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SelectActivity.ui'
#
# Created by: PyQt5 UI code generator 5.13.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow3(object):
    def setupUi(self, MainWindow3):
        MainWindow3.setObjectName("MainWindow3")
        MainWindow3.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow3)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupBox.sizePolicy().hasHeightForWidth())
        self.groupBox.setSizePolicy(sizePolicy)
        self.groupBox.setObjectName("groupBox")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.groupBox)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.FMRadio = QtWidgets.QPushButton(self.groupBox)
        self.FMRadio.setObjectName("FMRadio")
        self.horizontalLayout_2.addWidget(self.FMRadio)
        self.HydrogenLine = QtWidgets.QPushButton(self.groupBox)
        self.HydrogenLine.setObjectName("HydrogenLine")
        self.horizontalLayout_2.addWidget(self.HydrogenLine)
        self.Deconv = QtWidgets.QPushButton(self.groupBox)
        self.Deconv.setObjectName("Deconv")
        self.horizontalLayout_2.addWidget(self.Deconv)
        self.RadioDB = QtWidgets.QPushButton(self.groupBox)
        self.RadioDB.setObjectName("RadioDB")
        self.horizontalLayout_2.addWidget(self.RadioDB)
        self.FlightHacker = QtWidgets.QPushButton(self.groupBox)
        self.FlightHacker.setObjectName("FlightHacker")
        self.horizontalLayout_2.addWidget(self.FlightHacker)
        self.horizontalLayout.addWidget(self.groupBox)
        self.verticalLayout.addLayout(self.horizontalLayout)
        MainWindow3.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow3)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 22))
        self.menubar.setObjectName("menubar")
        MainWindow3.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow3)
        self.statusbar.setObjectName("statusbar")
        MainWindow3.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow3)
        QtCore.QMetaObject.connectSlotsByName(MainWindow3)

    def retranslateUi(self, MainWindow33):
        _translate = QtCore.QCoreApplication.translate
        MainWindow3.setWindowTitle(_translate("MainWindow33", "MainWindow33"))
        self.label.setText(_translate("MainWindow33", "TextLabel"))
        self.groupBox.setTitle(_translate("MainWindow33", "GroupBox"))
        self.FMRadio.setText(_translate("MainWindow33", "PushButton"))
        self.HydrogenLine.setText(_translate("MainWindow33", "PushButton"))
        self.Deconv.setText(_translate("MainWindow33", "PushButton"))
        self.RadioDB.setText(_translate("MainWindow33", "PushButton"))
        self.FlightHacker.setText(_translate("MainWindow33", "PushButton"))
