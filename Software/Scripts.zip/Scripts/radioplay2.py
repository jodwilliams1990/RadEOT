import subprocess
import os
import time

f=open("/home/pi/Documents/Scripts/rpconf2.txt", "r")
timer=str(f.readline())[:-1]
radiostat=str(f.readline())[:-1]
Rate=str(f.readline())[:-1]
Gain1=str(f.readline())[:-1]

print("Playing ", radiostat, "for ", timer, "ms, with a gain of ", Gain1, "and a rate of ", Rate)
radarg='rtl_fm -f ' + radiostat + ' -s ' + str(int(1000*float(Rate))) + ' -g ' + str(float(Gain1)) +' | aplay -t raw -r 200000 -f S16_LE &'
#print(radarg)
#radarg='rtl_fm -f ' + radiostat + ' -s 44100 -g 50 | aplay -t raw -r 44100 -f S16_LE &'
#print(radarg)
#print(rada)
procrp=subprocess.Popen([radarg], shell=True)
timea=float(timer)/1000
while timea>0:
    print(timea)
    time.sleep(1)
    timea=timea-1
    
    
os.system('pkill rtl_fm')
        #radarg='rtl_fm -f ' + radiostat + ' -s ' + str(1000*float(Rate)) + ' -g ' + str(Gain1) +' | aplay -t raw -r 44100 -f S16_LE'
        #print(radarg)
        #procrp=subprocess.Popen([radarg], shell=True)
        #time.sleep(timer/1000)
        #os.system('pkill rtl_fm')
