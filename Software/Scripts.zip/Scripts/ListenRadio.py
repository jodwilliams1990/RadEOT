import os
import sys
import os.path
import sqlite3
import datetime
import time
from pathlib import Path

from PyQt5.QtWidgets import QMainWindow, QMessageBox, QSlider, QAction, qApp, QApplication, QWidget, QLabel, QSizePolicy, QGridLayout, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton, QSplitter, QFrame, QComboBox, QTabWidget
from PyQt5.QtGui import QIcon, QMovie, QPixmap
from PyQt5.QtCore import QByteArray, QSize
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import QtWidgets, QtCore, QtGui

from RadioWindow import Ui_RadioWindow

class RadioWindow(QtWidgets.QMainWindow, Ui_RadioWindow):
    switch_window = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super(RadioWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('Listen to Radio')
        self.showMaximized()

        image_folder = Path("Buttons/")


        questionlist = self.read_from_db()
        questionliststr = [item for t in questionlist for item in t]
        question, optA, optB, optC, optD, Ans = questionliststr
        print(question, optA, optB, optC, optD, Ans)

        self.Question.setPlainText(question)
        self.Question.setReadOnly(True)
        self.Ans_A.setText(optA)
        self.Ans_B.setText(optB)
        self.Ans_C.setText(optC)
        self.Ans_D.setText(optD)

       
    # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(image_folder, 'homeBlue2.png')), 'Home', self)
        homeAct.triggered.connect(qApp.quit) 
        # Back button #
        backAct = QAction(QIcon(os.path.join(image_folder, 'backBlue2.png')), 'Back', self)
        backAct.triggered.connect(qApp.quit)
        # Forward #
        forwardAct = QAction(QIcon(os.path.join(image_folder, 'forwardBlue2.png')), 'Forward', self)
        forwardAct.triggered.connect(qApp.quit)
        # Refresh #
        refreshAct = QAction(QIcon(os.path.join(image_folder, 'refreshBlue2.png')), 'Refresh', self)
        #refreshAct.triggered.connect = self.InfoWindow.show()

        # Help button #
        helpAct = QAction(QIcon(os.path.join(image_folder, 'helpBlue2.png')), 'Help', self)
        helpAct.triggered.connect(qApp.quit)

        exitAct = QAction(QIcon(os.path.join(image_folder, 'exitBlue2.png')), 'Exit', self)
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Back')
        self.toolbar.addAction(backAct)
        self.toolbar = self.addToolBar('Forward')
        self.toolbar.addAction(forwardAct)
        self.toolbar = self.addToolBar('Refresh')
        self.toolbar.addAction(refreshAct)
        self.toolbar = self.addToolBar('Help')
        self.toolbar.addAction(helpAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)

    def read_from_db(self):
        conn = sqlite3.connect('question.db')
        c = conn.cursor()
        c.execute("SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer FROM radio ORDER BY RANDOM() LIMIT 1;")
      #  c.execute("SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer FROM radio")
        questionlist = c.fetchall()
        print(questionlist)
        c.close()
        conn.close()
        return questionlist





        
    def close_application(self):
        choice = QMessageBox.question(self,'Exit',
                                            "Do you really want to quit RadEOT?",
                                             QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass
'''
class listen():
    def __init__(self,master):
                self.master = master
                self.frame = Frame(self.master)
                self.quit4 = Button(self.master, text="Quit", command = self.frame.quit,height = 3, width = 10, highlightbackground='#c63f33')
                self.quit4.place(relx=0.5, rely=0.4, anchor=CENTER)
                label_freq = Label(master, text = "What frequency do you want to tune to?")
                label_freq.place(relx = 0.5, rely = 0.1, anchor = CENTER)
                self.entry1 = Entry(self.master)
                self.button1 = Button(self.master, text="Get", command=self.on_button)
                self.entry1.place(relx=0.5, rely=0.2, anchor=CENTER)
                self.button1.place(relx=0.5, rely=0.25, anchor=CENTER)
                self.entry2 = Entry(self.master)
                self.entry2.place(relx=0.5, rely=0.3, anchor=CENTER)
    def on_button(self):
                freq = self.entry1.get()
                timer = self.entry2.get()
                radio_play = 'rtl_fm -M wbfm -f' + str(freq) + 'M | play -r 32k -t raw -e s -b 16 -c 1 -V1 - &'
                radio_stop = 'sleep ' + str(timer) + '; pkill rtl_fm'
                os.system(radio_play)
                os.system(radio_stop)
'''

def login(self):
    self.switch_window.emit()

''''

#If FM Radio chosen follow this path
class Radio():

        def __init__(self, master):
                self.master = master
                self.frame = Frame(self.master)
                self.r1 = Button(self.master, text="Yes", command=self.radio_yes, height = 3, width = 10, bg = 'blue')
                self.r2 = Button(self.master, text="No", command=self.radio_no, height = 3, width = 10, bg='blue')
                self.quit3 = Button(self.master, text="Quit", command = self.frame.quit, height = 3, width = 10, bg='red')

                self.quit3.place(relx=0.5, rely=0.4, anchor=CENTER)
                self.r1.place(relx=0.4, rely=0.2, anchor=CENTER)
                self.r2.place(relx=0.6, rely=0.2, anchor=CENTER)

                label_tune = Label(master, text = "Would you like to tune the radio yourself?")
                label_tune.place(relx = 0.5, rely = 0.05, anchor = CENTER)

        #leave the gui and open other software
        def radio_yes(self):
                os.chdir('/usr/local/bin')
                os.system('gqrx')#./gqrx; ./gqrx')
                os.chdir('/home/pi/Documents/scripts')

        #open new window to pick radio station
        def radio_no(self):
                self.master.withdraw()
                self.newWindow3= Toplevel(self.master)
                nw3 = Tune(self.newWindow3)             
                self.newWindow3.geometry('%dx%d+0+0' % (width,height))
                self.newWindow3.title('FM Radio')


#If want auto tune follow this so can pick choice of 2 radio stations
#This could be adapted to just have space to enter fm frequency and play straight from gui
class Tune():

        def __init__(self,master):
                self.master = master
                self.frame = Frame(self.master)
                self.fm1 = Button(self.master, text="National Radio", command=self.fm1, height = 3, width = 10, bg='blue')
                self.fm2 = Button(self.master, text="Local Radio", command=self.fm2,height = 3, width = 10, bg = 'blue')
                self.quit1 = Button(self.master, text="Quit", command = self.frame.quit,height = 3, width = 10, bg='red')

                self.quit1.place(relx=0.5, rely=0.5, anchor=CENTER)
                self.fm1.place(relx=0.4, rely=0.3, anchor=CENTER)
                self.fm2.place(relx=0.6, rely=0.3, anchor=CENTER)

                label_station = Label(master, text = "Which Radio Station would you like to listen to?")
                label_station.place(relx = 0.5, rely = 0.2, anchor = CENTER)

                label_time = Label(master, text = "How long do you want to listen for? (in seconds)")
                label_time.place(relx = 0.5, rely = 0.05, anchor = CENTER)

                self.entry = Entry(self.master)
                self.entry.place(relx=0.5, rely=0.1, anchor=CENTER)

                #KEYPAD buttons
                self.number1 = Button(self.master, text = "1", command = self.num1)
                self.number1.place(relx = 0.15,rely=0.1,anchor=CENTER)

                self.number2 = Button(self.master, text = "2", command = self.num2)
                self.number2.place(relx = 0.2,rely=0.1,anchor=CENTER)

                self.number3 = Button(self.master, text = "3", command = self.num3)
                self.number3.place(relx = 0.25,rely=0.1,anchor=CENTER)

                self.number4 = Button(self.master, text = "4", command = self.num4)
                self.number4.place(relx = 0.15,rely=0.2,anchor=CENTER)

                self.number5 = Button(self.master, text = "5", command = self.num5)
                self.number5.place(relx = 0.2,rely=0.2,anchor=CENTER)

                self.number6 = Button(self.master, text = "6", command = self.num6)
                self.number6.place(relx = 0.25,rely=0.2,anchor=CENTER)

                self.number7 = Button(self.master, text = "7", command = self.num7)
                self.number7.place(relx = 0.15,rely=0.3,anchor=CENTER)

                self.number8 = Button(self.master, text = "8", command = self.num8)
                self.number8.place(relx = 0.2,rely=0.3,anchor=CENTER)

                self.number9 = Button(self.master, text = "9", command = self.num9)
                self.number9.place(relx = 0.25,rely=0.3,anchor=CENTER)

                self.number0 = Button(self.master, text = "0", command = self.num0)
                self.number0.place(relx = 0.15,rely=0.4,anchor=CENTER)

                self.numberB = Button(self.master, text = "Clear", command = self.numB)
                self.numberB.place(relx = 0.22,rely=0.4,anchor=CENTER)

        #Functions to put number in the entry box
        def num1(self):
                self.entry.insert(0,"1")

        def num2(self):
                self.entry.insert(0,"2")

        def num3(self):
                self.entry.insert(0,"3")

        def num4(self):
                self.entry.insert(0,"4")

        def num5(self):
                self.entry.insert(0,"5")

        def num6(self):
                self.entry.insert(0,"6")

        def num7(self):
                self.entry.insert(0,"7")

        def num8(self):
                self.entry.insert(0,"8")

        def num9(self):
                self.entry.insert(0,"9")

        def num0(self):
                self.entry.insert(0,"0")

        def numB(self):
                self.entry.delete(0,END)


        #fn for national station, stops after secs entered by user
        def fm1(self):
                print ("BBC Radio 1")
                timer = self.entry.get()
                os.chdir('/usr/local/bin/rtlfm')
                os.system('rtl_fm -M wbfm -f 97.9M | play -r 32k -t raw -e s -b 16 -c 1 -V1 - &')
                os.chdir('/home/pi/Documents/scripts')

                radio_stop = 'sleep ' + str(timer) + '; pkill rtl_fm'
                print ("radio_stop")                
                os.system(radio_stop)

        #fn for a local station, stops after secs entered by user
        def fm2(self):
                print ("BBC Radio Leicester")
                timer = self.entry.get()
                os.chdir('/usr/local/bin')
                os.system('rtl_fm -M wbfm -f 104.9M | play -r 32k -t raw -e s -b 16 -c 1 -V1 - &')
                radio_stop = 'sleep ' + str(timer) + '; pkill rtl_fm'
                os.system(radio_stop)
                os.chdir('/home/pi/Documents/scripts')

class listen():
    def __init__(self,master):
                self.master = master
                self.frame = Frame(self.master)
                self.quit4 = Button(self.master, text="Quit", command = self.frame.quit,height = 3, width = 10, highlightbackground='#c63f33')
                self.quit4.place(relx=0.5, rely=0.4, anchor=CENTER)
                label_freq = Label(master, text = "What frequency do you want to tune to?")
                label_freq.place(relx = 0.5, rely = 0.1, anchor = CENTER)
                self.entry1 = Entry(self.master)
                self.button1 = Button(self.master, text="Get", command=self.on_button)
                self.entry1.place(relx=0.5, rely=0.2, anchor=CENTER)
                self.button1.place(relx=0.5, rely=0.25, anchor=CENTER)
                self.entry2 = Entry(self.master)
                self.entry2.place(relx=0.5, rely=0.3, anchor=CENTER)
    def on_button(self):
                freq = self.entry1.get()
                timer = self.entry2.get()
                radio_play = 'rtl_fm -M wbfm -f' + str(freq) + 'M | play -r 32k -t raw -e s -b 16 -c 1 -V1 - &'
                radio_stop = 'sleep ' + str(timer) + '; pkill rtl_fm'
                os.system(radio_play)
                os.system(radio_stop)

'''
style = '''
QWidget {
    background-color: black;
    color: white; 
    font-size: 24px;
} 

QLabel {
    background-color: black;
    font: Lucida Console;
    font-size: 24px;
    color: white; 
}      

QComboBox {
    background-color: black; 
    color: white; 
    font-size: 24px;
}

PushButton {
    background-color: black; 
    color: white; 
    font-size: 24px;
}
    
QPushButton:hover {
    background-color: black; 
    color: darkgrey;
    font-size: 26px;
}

QMessageBox {
    background-color: 
    black; 
    color: white; 
    font-size: 24px;
} 

QTextEdit {
background-color: black; 
color: white; 
font-size: 24px; 
border: 0;
}

QSlider {
background-color: black; 
color: white; 
font-size: 24px; 
border: 0;
}

QTabWidget {
background-color: black; 
color: white; 
font-size: 24px; 
}
QTabBar {
background-color: white; 
color: black; 
font-size: 24px; 
}

'''

class Controller:

    def __init__(self):
        pass

    def show_login(self): 
        self.window = RadioWindow()
        #self.window.switch_window.connect(self.show_KSWindow)
        self.window.show()
       # self.window.close()




def main():
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet(style)
    controller = Controller()
    controller.show_login()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
    app = QApplication(sys.argv)