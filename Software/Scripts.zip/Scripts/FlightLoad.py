import sys
import os
import os.path
import subprocess
import sqlite3
import datetime
import time
import socket



from PyQt5.QtWidgets import QMainWindow, QMessageBox, QAction, qApp, QApplication, QWidget, QLabel, QSizePolicy, QGridLayout, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton, QSplitter, QFrame, QComboBox
from PyQt5.QtGui import QIcon, QMovie, QPixmap
from PyQt5.QtCore import QByteArray, QSize, pyqtSignal, QThread
from PyQt5 import QtCore, QtGui, QtWidgets
from pathlib import Path
## functools can be use in PyQT5 signal/slots instead of passing args with lambda  #
import urllib.error
import urllib.request
import urllib.response


from functools import partial 

from checkwifi import Ui_CheckWiFiWindow
from selectflightpath import Ui_SelectFlightWindow

TIME_LIMIT = 100

class External(QThread):
    """
    Runs a counter thread.
    """
    countChanged = pyqtSignal(int)

    def run(self):
        count = 0
        while count < TIME_LIMIT:
            count +=10
            time.sleep(1)
            try:
            # connect to the host -- tells us if the host is actually
            # reachable
                testwebpage = urllib.request.urlopen("http://google.com")#, timeout=1)

                self.countChanged.emit(count)
                print("Internet Connection found")
                #return True
            except urllib.error.URLError: 
                print("No internet connection - continue checking for 10 seconds")
                self.countChanged.emit(count)
                #pass
                #return False          

class checkwifiWindow(QtWidgets.QMainWindow, Ui_CheckWiFiWindow):
    ## No int val with switch window command because only process forward and no tool bar on window ##
    ## Must change this if window order changes! ##
    ## See PyQt5 section of RPi guide ##
    switch_window_emit = QtCore.pyqtSignal(int)
    
    def __init__(self, parent=None):
        super(checkwifiWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('Checking for WiFi availability...')
        #os.chdir(Imagepath)
        #self.setWindowIcon(QIcon('Rlogo.png'))
        #os.chdir(BASE_DIR)
        self.hideallresults()
        self.initprogressbar()


    def initprogressbar(self):
        self.WiFiprogressBar.setMaximum(100)
        self.CheckConnBtn.clicked.connect(self.onButtonClick)

    def onButtonClick(self):
        self.calc = External()
        self.calc.countChanged.connect(self.onCountChanged)
        self.calc.start()

    def onCountChanged(self, value):

        self.WiFiprogressBar.setValue(value)
    
    def hideallresults(self):
        self.StartLabel.hide()
        self.StartBtn.hide()
        self.ProceedLabel.hide()
        self.ProceedBtn.hide()
    
    def ProceedSelected(self):
        val = 3
        switch_window_emit = QtCorepyqtSignal(val)     


class Controller:

    def __init__(self):
        pass

    def show_checkwifiWindow(self):
## index relates to the switch window controller 0 = refresh, 1 = home, 2 = back, 3 = next window/forward ###
        self.window = checkwifiWindow()
     #   self.window.switch_window.connect(self.show_SelectWindow)
        self.window.show()

def main():
    app = QApplication(sys.argv)
#    app.setStyleSheet(style)
    controller = Controller()
    controller.show_checkwifiWindow()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()