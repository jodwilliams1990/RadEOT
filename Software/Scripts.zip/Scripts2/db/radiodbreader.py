import pandas as pd
import numpy as np


reader = pd.read_hdf('database.h5')
ffo = reader['ffrom'].astype(np.float)
print(ffo)
fto = reader['fto'].astype(np.float)
print(fto)
de1 = reader['descr1']
de2 = reader['descr2']
s=''
ftest= 1.1
utest='GHz'
if utest == 'kHz':
    ftest=ftest/1000
elif utest == 'GHz':
    ftest=ftest*1000

for i in range (0,len(ffo)):
    #print(ftest, type(ftest), ffo[i], fto[i])
    if ftest >= ffo[i] and ftest<=fto[i]:
        sstring=str(ftest)+ "MHz: " + str(de1[i]) + ' ' + str(de2[i])+"\n"
        s=s+ sstring
        #print(ftest, 'MHz: ', de1[i], de2[i])
print(s)