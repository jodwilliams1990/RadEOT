import sys
import os
import os.path
import subprocess
import sqlite3
import datetime
import time
import random
import math
import pandas as pd
import numpy as np
from subprocess import check_output 
from PyQt5.QtWidgets import QMainWindow, QMessageBox, QAction, qApp, QApplication, QWidget, QLabel, QSizePolicy, QGridLayout, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton, QSplitter, QFrame, QComboBox
from PyQt5.QtGui import QIcon, QMovie, QPixmap
from PyQt5.QtCore import QByteArray, QSize, pyqtSignal, QThread
from PyQt5 import QtCore, QtGui, QtWidgets
from pathlib import Path

## functools can be use in PyQT5 signal/slots instead of passing args with lambda  ##
from functools import partial   

##UI Files - Replace and update the .ui files with latest designs from QtDesigner/Creator##
## UI Files for GUI start selections ##
from RWindow import Ui_MainWindow
from KSWindow import Ui_KSWindow
from InfoWindow import Ui_InfoWindow
#from pdfViewer import Ui_pdfViewWindow

## UI Files for Radio Screeens ##
from RadioWindow2 import Ui_RadioWindow
from PlaneWindow import Ui_RadioWindow as Ui_FlightHackerWindow #from flighthacker import Ui_FlightHackerWindow
from RadioWindowDB import Ui_RadioWindow as Ui_RadioDBWindow
from hlineWindow import Ui_RadioWindow as Ui_HlineWindow
from loginscreen import Ui_userlogin as UIlogin
from loginscreen2 import Ui_RadioWindow as UIlogin2
#from deconv

class RWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    ## No int val with switch window command because only process forward and no tool bar on window ##
    ## Must change this if window order changes! ##
    ## See PyQt5 section of RPi guide ##
    switch_window = QtCore.pyqtSignal()
    
    def __init__(self, parent=None):
        super(RWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('Welcome to RadEOT!')
        
        ##Set filepath from images,db and buttons##
        ##This is dynamic so that if file structure in RPi guide is kept you can just shove 'Scripts' in any file path 
        ## this will track where to find stuff accordingly :) ##
        global BASE_DIR
        BASE_DIR = Path.cwd()
        print(BASE_DIR)
        global Textpath
        Textpath = Path.cwd() / "txt"
        global DBpath
        DBpath = Path.cwd() / "db"
        print(DBpath)
    ##  Path to RTL Env not required for RPi ##
    #    global RTLFMpath
    #    RTLFMpath = Path.cwd() / "rtl-sdr"
        global Buttonpath
        Buttonpath = Path.cwd() / "images" / "buttons"
        global Imagepath
        Imagepath = Path.cwd() / "images" 
        os.chdir(Imagepath)

        self.setWindowIcon(QIcon('Rlogo.png'))
        self.showMaximized()
        
        # Create widget #
        pixmap = QPixmap("RadeotLogo.png")
        pixmap = pixmap.scaled(750, 750, QtCore.Qt.KeepAspectRatio)
        self.Radeotlabel.setPixmap(pixmap)
        self.Radeotlabel.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)        
        self.Radeotlabel.setAlignment(QtCore.Qt.AlignCenter)   
        self.Radeotlabel.mousePressEvent = self.doSomething

    def doSomething(self, event):
        os.chdir(BASE_DIR)
        ## This is a great little bit of code that tracks mouse click on the RadEOT logo (or any other image) ##
        ## Basically it turns any image into a button - awesome little bit of GUI magic! ##
        self.switch_window.emit()

class LWindow(QtWidgets.QMainWindow, UIlogin):
    ## No int val with switch window command because only process forward and no tool bar on window ##
    ## Must change this if window order changes! ##
    ## See PyQt5 section of RPi guide ##
    switch_window = QtCore.pyqtSignal()
    
    def __init__(self, parent=None):
        super(LWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('RadEOT Secure Area')
        
        ##Set filepath from images,db and buttons##
        ##This is dynamic so that if file structure in RPi guide is kept you can just shove 'Scripts' in any file path 
        ## this will track where to find stuff accordingly :) ##
        global BASE_DIR
        BASE_DIR = Path.cwd()
        global Textpath
        Textpath = Path.cwd() / "txt"
        global DBpath
        DBpath = Path.cwd() / "db"
        global Buttonpath
        Buttonpath = Path.cwd() / "images" / "buttons"
        global Imagepath
        Imagepath = Path.cwd() / "images" 
        os.chdir(Imagepath)

        self.setWindowIcon(QIcon('Rlogo.png'))
        self.showMaximized()
        
        self.pushButton.clicked.connect(self.on_click)
        
    def on_click(self):
        un = self.lineEdit_2.text()
        pa = self.lineEdit.text()
        try:
            if un == 'RadEOTUser' and pa == 'jodw1':
                self.login()
            else:
                pass
        except:
            pass
    
    def login(self):
        os.chdir(BASE_DIR)
        self.close()
        self.Radiowindow=LWindow2()
        self.Radiowindow.show()

class LWindow2(QtWidgets.QMainWindow, UIlogin2):
    ## No int val with switch window command because only process forward and no tool bar on window ##
    ## Must change this if window order changes! ##
    ## See PyQt5 section of RPi guide ##
    switch_window = QtCore.pyqtSignal()
    
    def __init__(self, parent=None):
        super(LWindow2, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('RadEOT Secure Area')
        
        ##Set filepath from images,db and buttons##
        ##This is dynamic so that if file structure in RPi guide is kept you can just shove 'Scripts' in any file path 
        ## this will track where to find stuff accordingly :) ##
        global BASE_DIR
        BASE_DIR = Path.cwd()
        global Textpath
        Textpath = Path.cwd() / "txt"
        global DBpath
        DBpath = Path.cwd() / "db"
        global Buttonpath
        Buttonpath = Path.cwd() / "images" / "buttons"
        global Imagepath
        Imagepath = Path.cwd() / "images" 
        os.chdir(Imagepath)

        self.setWindowIcon(QIcon('Rlogo.png'))
        self.showMaximized()
        # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(Buttonpath, 'homeBlue2.png')), 'Home', self)
        homeAct.setToolTip('Go home - pick a new activity')
        homeAct.triggered.connect(self.home_window) 
        # Exit button #
        exitAct = QAction(QIcon(os.path.join(Buttonpath, 'exitBlue2.png')), 'Exit', self)
        exitAct.setToolTip('Exit app')
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)

        os.chdir(BASE_DIR)  
        os.chdir(DBpath)
        searchfile = [".xlsx"]
        lof=os.listdir(str(DBpath))
        matching = [s for s in lof if any(xs in s for xs in searchfile)]
        matching.append('New')
        RadioList = matching
        self.SelectRadio.addItems(RadioList)

        bkgcolourlist  = ("Black","White","Blue","Red", "Green")  #Black
        fontcolourlist  = ("Black","White","Blue","Red", "Green") #White
        locationlist  = ("Leicester","Northallerton","Southport","Manchester", "Birmingham", "Leeds", "London", "Bristol", "Newcastle") #White
        self.comboBox.addItems(bkgcolourlist)
        self.comboBox_2.addItems(fontcolourlist)
        self.comboBox_3.addItems(locationlist)

        os.chdir(BASE_DIR)
        self.RadioStartbtn2.clicked.connect(self.launchdatabaseeditor)
        self.RadioStartbtn2_3.clicked.connect(self.dbtoradeot)
        self.RadioStartbtn2_4.clicked.connect(self.dbdelete)
        self.RadioStartbtn2_2.clicked.connect(self.savesettings)
    
    def savesettings(self):
        bkgcol = str(self.comboBox_2.currentText())
        col = str(self.comboBox.currentText())
        loc= str(self.comboBox_3.currentText())
        settingsconffile=open("/home/pi/Documents/Scripts/settingsconf.txt", "w")
        settingsconffile.write(str(bkgcol)+'\n'+str(col)+'\n'+str(loc))
        settingsconffile.close()
    
    def dbdelete(self):
        deletefile = str(self.SelectRadio.currentText())
        os.chdir(DBpath)
        os.remove(deletefile)
        self.SelectRadio.clear()
        searchfile = [".xlsx"]
        lof=os.listdir(str(DBpath))
        matching = [s for s in lof if any(xs in s for xs in searchfile)]
        matching.append('New')
        RadioList = matching
        self.SelectRadio.addItems(RadioList)
    
    def dbtoradeot(self):
        searchfile = ["question.db"]
        os.chdir(DBpath)
        try:
            os.remove('question.db')
        except:
            pass
        dbconffile=open("/home/pi/Documents/Scripts/db/dbconf.txt", "w")
        dbconffile.write(str(self.SelectRadio.currentText()))
        dbconffile.close()
        os.system("python3 GenerateQuestiondb.py")
        
    def launchdatabaseeditor(self):
        filechoice = str(self.SelectRadio.currentText())
        os.chdir(DBpath)
        if filechoice == 'New':
            nf='RadEOT-'+ datetime.datetime.now().strftime("%d-%m-%Y-%H:%M")
            ossstring='cp /home/pi/Documents/Scripts/db/Template/Template.xlsx /home/pi/Documents/Scripts/db/'+nf+'.xlsx' 
            os.system(ossstring)
            ossstring='libreoffice /home/pi/Documents/Scripts/db/{}.xlsx'.format(nf)
            os.system(ossstring)
        else:        
            ossstring='libreoffice {}'.format(filechoice) #RadeotQuestions.xlsx'
            os.system(ossstring)#libreoffice RadeotQuestions.xlsx')
        os.chdir(BASE_DIR)
    
    def home_window(self):
        os.chdir(BASE_DIR)
        self.close()
        os.system('python3 runradeot.py')
    def close_application(self):
        choice = QMessageBox.question(self,'Exit',
                                            "Do you really want to quit RadEOT?",
                                             QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass

    def doSomething(self, event):
        os.chdir(BASE_DIR)
        ## This is a great little bit of code that tracks mouse click on the RadEOT logo (or any other image) ##
        ## Basically it turns any image into a button - awesome little bit of GUI magic! ##
        self.switch_window.emit()

class MoviePlayer(QWidget): 
    ## USing MoviePlayer as a widget to embed a GIF - I think this was the best way to do so when the app was simpler BUT...##
    ## I would change this and package into a UI file layout with the movie player widget embedded ##

    ## No int val with switch window command because only process forward and no tool bar on window ##
    ## MUST UPDATE IF WINDOW POSITION CHANGES ie. this is embedded further in the program and back / home tool buttons are added ##
    switch_window = QtCore.pyqtSignal()

    def __init__(self, filename, title, parent=None): 
        QWidget.__init__(self, parent) 

        # setGeometry(x_pos, y_pos, width, height) #
        # x_pos and y_pos are placement in the window space. width and height are widget or image size #
        # See Rpi Guide for more info #

        self.setGeometry(200, 200, 400, 400)
        os.chdir(Imagepath)
        self.setWindowTitle("Choose an Activity...")
        self.setWindowIcon(QIcon('Rlogo.png'))

        #self.showMaximized() <------Do not use on RPi for this window as it f**cks with the aspect ratios as haven't used QtDesigner##
        ### Window / container widget must be max size 800 x 480 pix and NO MORE otherwise won't fit screen - see RPi guide for more info ###
        self.createLayout()
        # set up the movie screen on a label
        self.movie_screen = QLabel()
        # expand and center the label 
        #self.movie_screen.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)   
        #self.movie_screen.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Maximum)      
        self.movie_screen.setAlignment(QtCore.Qt.AlignCenter) 

        main_layout = QGridLayout()     
        main_layout.addWidget(self.movie_screen)
        main_layout.addWidget(self.QGroupBox)
        self.setLayout(main_layout) 
           
        # use an animated gif file you have in the working folder
        # or give the full file path
        self.movie = QMovie("RadeotLogo.png", QByteArray(), self) #location.gif
        self.movie.setCacheMode(QMovie.CacheAll) 
        self.movie.setSpeed(100) 
        self.movie_screen.setMovie(self.movie) 
        self.showMaximized()
        #self.showFullScreen()
        self.movie.start()

    def createLayout(self):
        self.QGroupBox = QGroupBox("Welcome to RadEOT! Please choose an activity...")
        #self.QGroupBox.setStyleSheet('QGroupBox {background-color: black; color: white; font-size: 36px;} QGroupBox:hover {background-color: black; color: darkgrey;}')
        layout = QGridLayout()
        #layout = QHBoxLayout()
        
        ## Again did this window early on outside of QtDesigner - maybe update in future but works fine for a simple window ##
        self.Activity1 = QtWidgets.QPushButton('|   FM Radio  |\n|                   |')
        self.Activity1.clicked.connect(self.UpdateActivityRadio)
        self.Activity2 = QtWidgets.QPushButton('|       Radio     |\n|   Database   |')
        self.Activity2.clicked.connect(self.UpdateActivityRadioDB)
        self.Activity3 = QtWidgets.QPushButton('| Demod Radio  |\n| Coming Soon! |')
        self.Activity3.clicked.connect(self.UpdateActivityRadioDeconv)    
        self.Activity4 = QtWidgets.QPushButton('|   Hydrogen  |\n|       Line       |')
        self.Activity4.clicked.connect(self.UpdateActivityHLine)
        self.Activity5 = QtWidgets.QPushButton('|      Flight     |\n|   Tracker    |')
        self.Activity5.clicked.connect(self.UpdateActivityFlight)
        self.Activity6 = QtWidgets.QPushButton('|     Secure    |\n|      Area      |')
        self.Activity6.clicked.connect(self.SecureArea)

        layout.addWidget(self.Activity1,0,0)
        layout.addWidget(self.Activity2,0,1)
        layout.addWidget(self.Activity3,0,2)
        layout.addWidget(self.Activity4,0,3)
        layout.addWidget(self.Activity5,0,4)
        layout.addWidget(self.Activity6,1,2)
        self.QGroupBox.setLayout(layout)

    def UpdateActivityRadio(self):
        global activity_key
        activity_key = "radio"
        self.login()

    def UpdateActivityRadioDB(self):
        global activity_key
        activity_key = "radioDB"
        self.login()

    def UpdateActivityRadioDeconv(self):
        global activity_key
        activity_key = "radioDeconv"
        self.login()

    def UpdateActivityHLine(self):
        global activity_key
        activity_key = "hline"
        self.login()

    def UpdateActivityFlight(self):
        global activity_key
        activity_key = "flighthacker"
        self.login()
        
    def SecureArea(self):    
        global activity_key
        activity_key = "securearea"
        self.login()
        
    def login(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit()

class KSWindow(QtWidgets.QMainWindow, Ui_KSWindow):
    ## int val passed with swit_window emit signal to indicate load window home , prev or next window. ##
    switch_window = QtCore.pyqtSignal(int)

    def __init__(self, parent=None):
        super(KSWindow, self).__init__(parent)
        self.setupUi(self)
        os.chdir(Imagepath)
        self.setWindowTitle('Select Age')
        self.setWindowIcon(QIcon('Rlogo.png'))
        self.showMaximized()
        # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(Buttonpath, 'homeBlue2.png')), 'Home', self)
        homeAct.setToolTip('Go home - pick a new activity')
        homeAct.triggered.connect(self.home_window) 
        # Back button #
        backAct = QAction(QIcon(os.path.join(Buttonpath, 'backBlue2.png')), 'Back', self)
        backAct.setToolTip('Back')
        backAct.triggered.connect(self.back_window)
        # Forward #
        forwardAct = QAction(QIcon(os.path.join(Buttonpath, 'forwardBlue2.png')), 'Forward', self)
        forwardAct.setToolTip('Forward')
        forwardAct.triggered.connect(self.forward_window)
        # Refresh #
        refreshAct = QAction(QIcon(os.path.join(Buttonpath, 'refreshBlue2.png')), 'Refresh', self)
        refreshAct.triggered.connect(self.reload_window)
        # Help button #
        helpAct = QAction(QIcon(os.path.join(Buttonpath, 'helpBlue2.png')), 'Help', self)
        helpAct.setToolTip('Get help!')
        helpAct.triggered.connect(self.help_info)
        # Build button #
        buildAct = QAction(QIcon(os.path.join(Buttonpath, 'brick.png')), 'Build', self)
        buildAct.setToolTip('Learn how to build RadEOT')
        buildAct.triggered.connect(self.buildRadeot)

        exitAct = QAction(QIcon(os.path.join(Buttonpath, 'exitBlue2.png')), 'Exit', self)
        exitAct.setToolTip('Exit app')
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Back')
        self.toolbar.addAction(backAct)
        self.toolbar = self.addToolBar('Forward')
        self.toolbar.addAction(forwardAct)
        self.toolbar = self.addToolBar('Refresh')
        self.toolbar.addAction(refreshAct)
        self.toolbar = self.addToolBar('Help')
        self.toolbar.addAction(helpAct)
        self.toolbar = self.addToolBar('Build')
        self.toolbar.addAction(buildAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)

####  Styles set globally using qApp and style sheet ####
    ####  Manually make specific changes in windows if desired, using below code examples ####
        #self.EnterKS.setStyleSheet('QPushButton {background-color: black; color: white; font-size: 36px;} QPushButton:hover {background-color: black; color: darkgrey;}')
        #self.SelectKS.setStyleSheet('QComboBox {background-color: black; color: white; font-size: 36px;}')
        #self.TextKS.setStyleSheet('QLabel {background-color: black; color: white; font-size: 36px;}')
        #self.menubar.setStyleSheet('menuFile {background-color: white; color: black; font-size: 36px;} ')   
        #self.setStyleSheet('{background-color: black; color: white;} QMessageBox {background-color: black; color: white;} QPushButton {background-color: black; color: white;}')
        # Create widget
        
        ##Change directory to find dbs)## <--------------------------Need to add error trap here - if db not found then call and run Createdb.py ##
        ##Fetch info and process to a list for combo box ##
        os.chdir(DBpath)
        current = os.getcwd()
        ksList = self.KS_Combo()
        ksListstr = [item for t in ksList for item in t]
        self.SelectKS.addItems(ksListstr)
        self.EnterKS.clicked.connect(self.UpdateAge)  

    def KS_Combo(self):
        conn = sqlite3.connect('agekey.db')
        c = conn.cursor()
        c.execute("SELECT DISTINCT age FROM kstable")
        ksList = c.fetchall ()
        c.close()
        conn.close()
        return ksList

    def UpdateAge(self):
        ageval = str(self.SelectKS.currentText())      
        global keystage_txt
        current = os.getcwd()
        conn = sqlite3.connect('agekey.db')
        c = conn.cursor()
        age_query = "SELECT keystage FROM kstable WHERE age='"+ageval+"'"
        c.execute(age_query)
        ks = c.fetchall ()
        c.close()
        conn.close()
        keystage_val = [item for t in ks for item in t]
        keystage_txt = ''.join(keystage_val)
        timenow=datetime.datetime.now()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        logstring=tn + '' + keystage_txt + '' + ageval + "\n"
        radeotlog.write(logstring)
        radeotlog.close()
        self.login()

########################################################### Toolbar Functions ###################################################################
######## switch_window key 1 =home, 2 = back, 3 = forward/any'next page' actions ########################    
    def home_window(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit(1)
    def back_window(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit(2)   
    def forward_window(self):
        os.chdir(BASE_DIR)
        buttonReply = QMessageBox.question(self, 'Forward Button', "Please select a KeyStage to proceed.", QMessageBox.Ok)  
    def reload_window(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit(0)  
    def help_info(self):
        buttonReply = QMessageBox.question(self, 'Help Information', "Select your Key Stage so we can tailor RadEOT information, instructions and questions.", QMessageBox.Ok)
    def buildRadeot(self):
        os.chdir(BASE_DIR)
        file = "/home/pi/Documents/Scripts/BuildRadeot.pdf"
        subprocess.Popen([file],shell=True)
    def close_application(self):
        choice = QMessageBox.question(self,'Exit', "Do you really want to quit RadEOT?", QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass
#################################################### App Controller to Switch Window ###########################################################

    def login(self):
        os.chdir(BASE_DIR)   ##change dir back to base ##
  ## Can use 'sender' to log which button/action has sent a signal can be useful for signal/slots tracking can also use QSignalMapper also #####
  ## I have developed the switch_window.emit(ChangeWindowIndex) as each page links with multiple page - passing an int value with signal emit ##
  ## seemed the most efficient way of tracking page moves that wasn't tied to specific buttons incase of future layout changes etc etc #########
        #sender = self.sender() <---- This will store the buttonsender value 
        #print(sender)          <---- Print which button has sent signal
        self.switch_window.emit(3)


class InfoWindow(QtWidgets.QMainWindow, Ui_InfoWindow):
    switch_window = QtCore.pyqtSignal(int)

    def __init__(self, parent=None):
        super(InfoWindow, self).__init__(parent)
        self.setupUi(self)
        os.chdir(Imagepath)
        self.setWindowTitle('Activity Information')
        self.setWindowIcon(QIcon('Rlogo.png'))
         
        self.CheckKeyStage()
        self.StartButton.clicked.connect(self.LoadActivity)
        self.MoviePlayer2()
        
        self.showMaximized()
       # self.showFullScreen()
       # self.showMaximized()
        
    def MoviePlayer2(self):
        filename = activity_key
        #setGeometry(x_pos, y_pos, width, height)
        #self.setGeometry(200, 200, 400, 400)
        #self.showMaximized()
        #  self.movie_screen.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)   
        #  self.movie_screen.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)      
        self.movie_screen.setAlignment(QtCore.Qt.AlignCenter) 
        # use an animated gif file you have in the working folder
        # or give the full file path
        self.movie = QMovie(filename, QByteArray(), self) 
        self.movie.setCacheMode(QMovie.CacheAll) 
        self.movie.setSpeed(100) 
        self.movie_screen.setMovie(self.movie) 
        #self.movie_screen.resize(404, 227)
        self.movie.start()
        
        # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(Buttonpath, 'homeBlue2.png')), 'Home', self)
        homeAct.setToolTip('Go home - pick a new activity')
        homeAct.triggered.connect(self.home_window)
        # Back button #
        backAct = QAction(QIcon(os.path.join(Buttonpath, 'backBlue2.png')), 'Back', self)
        backAct.setToolTip('Back')
        backAct.triggered.connect(self.back_window)
        # Forward #
        forwardAct = QAction(QIcon(os.path.join(Buttonpath, 'forwardBlue2.png')), 'Forward', self)
        forwardAct.setToolTip('Forward')
        forwardAct.triggered.connect(self.forward_window)
        # Refresh #
        refreshAct = QAction(QIcon(os.path.join(Buttonpath, 'refreshBlue2.png')), 'Refresh', self)
        refreshAct.triggered.connect (self.reload_window)

        # Help button #
        helpAct = QAction(QIcon(os.path.join(Buttonpath, 'helpBlue2.png')), 'Help', self)
        helpAct.setToolTip('Get help!')
        helpAct.triggered.connect(self.help_info)

        # Build button #
        buildAct = QAction(QIcon(os.path.join(Buttonpath, 'brick.png')), 'Build', self)
        buildAct.setToolTip('Learn how to build RadEOT')
        buildAct.triggered.connect(self.buildRadeot)

        exitAct = QAction(QIcon(os.path.join(Buttonpath, 'exitBlue2.png')), 'Exit', self)
        exitAct.setToolTip('Exit app')
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Back')
        self.toolbar.addAction(backAct)
        self.toolbar = self.addToolBar('Forward')
        self.toolbar.addAction(forwardAct)
        self.toolbar = self.addToolBar('Refresh')
        self.toolbar.addAction(refreshAct)
        self.toolbar = self.addToolBar('Help')
        self.toolbar.addAction(helpAct)
        self.toolbar = self.addToolBar('Build')
        self.toolbar.addAction(buildAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)
        
    def CheckKeyStage (self):
        global keystage_txt
        os.chdir(Textpath)
        x = ["ks4", "ks5", "ks6"]
        if keystage_txt in x and activity_key!='securearea':
            keystage_val = "ks3"
            filetype = ".txt"
            textfile = "%s-%s%s" % (keystage_val, activity_key, filetype) 
        elif activity_key!='securearea': #else:
            filetype = ".txt"
            textfile = "%s-%s%s" % (keystage_txt, activity_key, filetype) 
        text=open(textfile).read()
        self.InfoText.setPlainText(text)
        self.InfoText.setReadOnly(True)

        os.chdir(BASE_DIR)
#################################################### App Controller to Switch Window ###########################################################

    def LoadActivity(self):
        os.chdir(BASE_DIR)
        self.login()

########################################################### Toolbar Functions ###################################################################
######## switch_window key 1 =home, 2 = back, 3 = forward/any'next page' actions ########################    
    def home_window(self):
        os.chdir(BASE_DIR)
        print(BASE_DIR)
        self.switch_window.emit(1)
    def back_window(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit(2)
    
    def forward_window(self):
        os.chdir(BASE_DIR)
        buttonReply = QMessageBox.question(self, 'Forward Button', "Please select a KeyStage to proceed.",QMessageBox.Ok)
    
    def reload_window(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit(0)
    
    def help_info(self):
        buttonReply = QMessageBox.question(self, 'Help Information', 
                                                    "This page provides introductory information for your chosen activity.\nMore information can be found in the help tab of the activity or by using this button.",
                                                        QMessageBox.Ok)
    def buildRadeot(self):
        os.chdir(BASE_DIR)
        file = ['okular',"/home/pi/Documents/Scripts/BuildRadeot.pdf"]
        subprocess.Popen([file],shell=True)

    def close_application(self):
        choice = QMessageBox.question(self,'Exit',
                                            "Do you really want to quit RadEOT?",
                                             QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass
#################################################### App Controller to Switch Window ###########################################################

    def login(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit(3)

class RadioWindow(QtWidgets.QMainWindow, Ui_RadioWindow):
    switch_window = QtCore.pyqtSignal(int)

    def __init__(self, parent=None):
        count=0
        super(RadioWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('Listen to Radio')
        self.showMaximized()
        os.chdir(Imagepath)
        
        self.setWindowIcon(QIcon('Rlogo.png'))
        # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(Buttonpath, 'homeBlue2.png')), 'Home', self)
        homeAct.setToolTip('Go home - pick a new activity')
        homeAct.triggered.connect(self.home_window)
        # Back button #
        backAct = QAction(QIcon(os.path.join(Buttonpath, 'backBlue2.png')), 'Back', self)
        backAct.setToolTip('Back')
        backAct.triggered.connect(self.back_window)
        # Forward #
        forwardAct = QAction(QIcon(os.path.join(Buttonpath, 'forwardBlue2.png')), 'Forward', self)
        forwardAct.setToolTip('Forward')
        forwardAct.triggered.connect(self.forward_window)
        # Refresh #
        refreshAct = QAction(QIcon(os.path.join(Buttonpath, 'refreshBlue2.png')), 'Refresh', self)
        refreshAct.triggered.connect(self.reload_window)
        # Help button #
        helpAct = QAction(QIcon(os.path.join(Buttonpath, 'helpBlue2.png')), 'Help', self)
        helpAct.setToolTip('Get help!')
        helpAct.triggered.connect(self.help_info)
        # Build button #
        buildAct = QAction(QIcon(os.path.join(Buttonpath, 'brick.png')), 'Build', self)
        buildAct.setToolTip('Learn how to build RadEOT')
        buildAct.triggered.connect(self.buildRadeot)

        exitAct = QAction(QIcon(os.path.join(Buttonpath, 'exitBlue2.png')), 'Exit', self)
        exitAct.setToolTip('Exit app')
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Back')
        self.toolbar.addAction(backAct)
        self.toolbar = self.addToolBar('Forward')
        self.toolbar.addAction(forwardAct)
        self.toolbar = self.addToolBar('Refresh')
        self.toolbar.addAction(refreshAct)
        self.toolbar = self.addToolBar('Help')
        self.toolbar.addAction(helpAct)
        self.toolbar = self.addToolBar('Build')
        self.toolbar.addAction(buildAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)

        os.chdir(BASE_DIR)

        self.hideAnsImages()
        self.setQuestion()
        self.helplabelfiller()

        RadioList = ("BBC R1", "BBCR2", "Classic FM", "BBC Leicester", "Capital FM - Manchester")
        TimeList = ("10 secs","30 secs","1 min","2 mins", "3 mins")
        self.SelectRadio.addItems(RadioList)
        self.TimeCombo.addItems(TimeList)
        self.TimeCombo2.addItems(TimeList)
        self.TimeCombo2_2.addItems(TimeList)
        # After each value change, slot "setCurrentSliderValue" will get invoked. 
        self.setCurrentSliderValue()
        self.FreqSlider.valueChanged.connect(self.setCurrentSliderValue)        

        self.RadioStartbtn.clicked.connect(self.UpdateRadioStation)
        self.RadioStartbtn2.clicked.connect(self.UpdateRadioStation2)
        self.RadioStartbtn2_2.clicked.connect(self.UpdateRadioStation3)

        self.RadioStopbtn.clicked.connect(self.StopRadio)
        self.RadioStopbtn2.clicked.connect(self.StopRadio)
        self.RadioStopbtn2_2.clicked.connect(self.StopRadio)

        self.FreqSlider_2.valueChanged.connect(self.setCurrentSliderValue2) 
        self.setCurrentSliderValue2()

        self.FreqSlider_3.valueChanged.connect(self.setCurrentSliderValue3) 
        self.setCurrentSliderValue3()
        
        self.FreqSlider_4.valueChanged.connect(self.setCurrentSliderValue4) 
        self.setCurrentSliderValue4()

    def helplabelfiller(self):
        hlf=open("/home/pi/Documents/Scripts/txt/help-radio.txt", "r").readline()
        self.HelpLabel.setText(hlf)
        
    def setCurrentSliderValue(self):
        FreqNum = self.FreqSlider.value()
        FreqmHz = FreqNum / 1000
        global CurrentFreq
        CurrentFreq = str(FreqmHz)
        self.CurrentValueLabel.setText(CurrentFreq)

    def setCurrentSliderValue2(self): #frequency
        FreqNum = self.FreqSlider_2.value()
        FreqmHz = FreqNum / 1000
        global CurrentFreq
        CurrentFreq = str(FreqmHz)
        self.CurrentValueLabel_2.setText(CurrentFreq)

    def setCurrentSliderValue3(self): #gain
        Gain = self.FreqSlider_3.value()
        Gain = Gain/1000
        global Gain1
        Gain1 = str(Gain)
        self.CurrentValueLabel_3.setText(Gain1)

    def setCurrentSliderValue4(self): #rate
        rate = self.FreqSlider_4.value()
        rate = rate/1000
        global Rate
        Rate = str(rate)
        self.CurrentValueLabel_4.setText(Rate)

    def UpdateRadioStation(self):
        radio = str(self.SelectRadio.currentText())
        global freq
        if radio == "BBC R1":
            freq = 98
        if radio == "BBCR2":
            freq = 89
        if radio == "Classic FM":
            freq = 100
        if radio == "BBC Leicester":
            freq = 104.9
        if radio == "Capital FM - Manchester":
            freq = 102
        
        global timer
        timer = str(self.TimeCombo.currentText())
        if timer == "10 secs":
            timer = 10000
        if timer == "30 secs":
            timer = 30000
        if timer == "1 min":
            timer = 60000
        if timer == "2 mins":
            timer = 120000
        if timer == "3 mins":
            timer = 180000       
        self.PlayRadio()

    def UpdateRadioStation2(self):
        global freq
        freq = CurrentFreq
        global timer
        timer = str(self.TimeCombo2.currentText())
        if timer == "10 secs":
            timer = 10000
        if timer == "30 secs":
            timer = 30000
        if timer == "1 min":
            timer = 60000
        if timer == "2 mins":
            timer = 120000
        if timer == "3 mins":
            timer = 180000
        self.PlayRadio()

    def PlayRadio(self):  
        radiostat=str(freq)+"M"      
        radioplayconffile=open("/home/pi/Documents/Scripts/rpconf.txt", "w")
        radioplayconffile.write(str(timer)+'\n'+str(radiostat))
        radioplayconffile.close()
        global check
        chrcheck = subprocess.Popen(['python3', '/home/pi/Documents/Scripts/radioplay.py'])
        timenow=datetime.datetime.now()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        logstring=tn+" Listened to "+ str(CurrentFreq) + "MHz for " + str(timer) + "s\n"
        radeotlog.write(logstring)
        radeotlog.close()

    def StopRadio(self):
        chrcheck.terminate()
        os.system('pkill rtl_fm')
        
    def UpdateRadioStation3(self):
        global freq
        freq = CurrentFreq
        global timer
        timer = str(self.TimeCombo2_2.currentText())
        if timer == "10 secs":
            timer = 10000
        if timer == "30 secs":
            timer = 30000
        if timer == "1 min":
            timer = 60000
        if timer == "2 mins":
            timer = 120000
        if timer == "3 mins":
            timer = 180000
        self.PlayRadio2()
       
    def PlayRadio2(self):  
        global freq
        global timer
        radiostat=str(freq)+"M"
        radioplayconffile=open("/home/pi/Documents/Scripts/rpconf2.txt", "w")
        radioplayconffile.write(str(timer)+'\n'+str(radiostat)+'\n'+str(Rate)+'\n'+str(Gain1))
        radioplayconffile.close()
        global chrcheck
        chrcheck = subprocess.Popen(['python3', '/home/pi/Documents/Scripts/radioplay2.py'])
        timenow=datetime.datetime.now()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        logstring=tn+" Listened to "+ str(CurrentFreq) + "MHz for " + str(timer) + "s with Rate " + str(Rate) + "and Gain " + str(Gain1) +"\n"
        radeotlog.write(logstring)
        radeotlog.close()

# not in use rtl-sdr in folder in Scripts    os.chdir("/usr/local/bin/rtlfm")  

    ################################ Notes for rtl-sdr ########################################################
    # Use:    rtl_fm -f freq [-options] [filename]
    #   [-f frequency_to_tune_to [Hz]
    #        use multiple -f for scanning (requires squelch)
    #        ranges supported, -f 118M:137M:25k
    #    [-M modulation (default: fm)]
    #        fm, wbfm, raw, am, usb, lsb
    #        wbfm == -M fm -s 170k -o 4 -A fast -r 32k -l 0 -E deemp
    #        raw mode outputs 2x16 bit IQ pairs
    #    [-s sample_rate (default: 24k)]
    #    [-d device_index (default: 0)]
    #    [-T enable bias-T on GPIO PIN 0 (works for rtl-sdr.com v3 dongles)]
    #    [-g tuner_gain (default: automatic)]
    #    [-l squelch_level (default: 0/off)]
    #    [-p ppm_error (default: 0)]
    #    [-E enable_option (default: none)]
    #        use multiple -E to enable multiple options
    #        edge:   enable lower edge tuning
    #        dc:     enable dc blocking filter
    #        deemp:  enable de-emphasis filter
    #        direct: enable direct sampling
    #        offset: enable offset tuning
    #    filename ('-' means stdout)
    #        omitting the filename also uses stdout

    # Experimental options:
    #    [-r resample_rate (default: none / same as -s)]
    #    [-t squelch_delay (default: 10)]
    #        +values will mute/scan, -values will exit
    #    [-F fir_size (default: off)]
    #        enables low-leakage downsample filter
    #        size can be 0 or 9.  0 has bad roll off
    #    [-A std/fast/lut choose atan math (default: std)]

    # Produces signed 16 bit ints, use Sox or aplay to hear them.
    #    rtl_fm ... | play -t raw -r 24k -es -b 16 -c 1 -V1 -
    #               | aplay -r 24k -f S16_LE -t raw -c 1 
    #      -M wbfm  | play -r 32k ...
    #      -s 22050 | multimon -t raw /dev/stdin    
    #############################################################################################################
    # To sample reception of  all commercial wide-band FM signals   use .....
    # rtl_fm -f 96.3e6 -M wbfm -s 200000 -r 48000 - | aplay -r 48k -f S16_LE
                                                         

    def setQuestion(self):
        try:
            freqq = float(CurrentFreq)
        except:
            freqq = 91
        KS=' '
        global question
        questionlist = self.read_from_dbks(keystage_txt)
        questionliststr = [item for t in questionlist for item in t]
        question, optA, optB, optC, optD, Ans, Notes, KS, Dependencies = questionliststr
        global AnswerHint
        AnswerHint = Notes
        global Answer
        Answer = Ans
        freqw=freqq+1

        if Dependencies == 'frequency':
            question=question.format(freqq, freqw)
        
        try:
            self.NewQuestion.clicked.disconnect(self.QuestionReset)
        except:
            pass
        self.QuestionLabel.setText(question)
        self.Ans_A.setText(optA)
        self.Ans_B.setText(optB)
        self.Ans_C.setText(optC)
        self.Ans_D.setText(optD)
        self.btnA.clicked.connect(self.SelectionA)
        self.btnB.clicked.connect(self.SelectionB)
        self.btnC.clicked.connect(self.SelectionC)
        self.btnD.clicked.connect(self.SelectionD)
        self.Hint.clicked.connect(self.setHintText)
        self.ClearSelection.clicked.connect(self.buttonReset)
        try:
            self.SubmitSelection.clicked.connect(self.submitAns)
        except:
            pass
        self.NewQuestion.clicked.connect(self.QuestionReset)

    def read_from_dbks(self, keystage_txt):
        os.chdir(DBpath)
        conn = sqlite3.connect('question.db')
        c = conn.cursor()
        if keystage_txt == 'ks6':
            c.execute("SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM radio ORDER BY RANDOM() LIMIT 1;")
        else:
            ksno=keystage_txt[-1:]
            sqlitestring="SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM radio WHERE KS LIKE '%{}' ORDER BY RANDOM() LIMIT 1;".format(ksno)
            c.execute(sqlitestring)
        questionlist = c.fetchall()
        c.close()
        conn.close()
        return questionlist
        os.chdir(BASE_DIR)
       
    def SelectionA(self):
        self.btnA.setStyleSheet("QPushButton { background-color: blue}")
        self.btnB.setEnabled(False)
        self.btnC.setEnabled(False)
        self.btnD.setEnabled(False)
        global selectedanswer
        selectedanswer =  "A" 

    def SelectionB(self):
        self.btnB.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnC.setEnabled(False)
        self.btnD.setEnabled(False)  
        global selectedanswer
        selectedanswer =  "B" 

    def SelectionC(self):
        self.btnC.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnD.setEnabled(False) 
        global selectedanswer
        selectedanswer =  "C" 

    def SelectionD(self):
        self.btnD.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnC.setEnabled(False)
        global selectedanswer 
        selectedanswer =  "D" 

    def setHintText(self):
        global AnswerHint
        self.HintAnsLabel.setText(AnswerHint)
      #  self.HintAnsText.setReadOnly(True)
        self.HintAnsLabel.show()
    
    def buttonReset(self):
        self.btnA.setStyleSheet("QPushButton { background-color: black }")
        self.btnB.setStyleSheet("QPushButton { background-color: black }")
        self.btnC.setStyleSheet("QPushButton { background-color: black }")
        self.btnD.setStyleSheet("QPushButton { background-color: black }")
        self.btnA.setEnabled(True)
        self.btnB.setEnabled(True)
        self.btnC.setEnabled(True)
        self.btnD.setEnabled(True) 
        self.hideAnsImages()
        global selectedanswer 
        selectedanswer =  ""
    
    def submitAns(self):
       ## Create widget < Was going to add tick / cross images here ##
       # correct_img = QPixmap((os.path.join(Buttonpath, 'tick.png')))
       # incorrect_img = QPixmap((os.path.join(Buttonpath, 'cross.png')))
       # self.Mark_D.setPixmap(correct)
        global ansstring
        correct ="Correct!"
        incorrect = "Incorrect"
        ansstring=incorrect
        if Answer == "A":
            self.btnA.setStyleSheet("QPushButton { background-color: white; color: black }")
          #  self.Mark_A.show()
          #  self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="A":
                    self.btnA.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_A.show()
                    self.Mark_A.setText(correct)
                    ansstring=correct
            except:
                pass
        elif Answer =="B":
            self.btnB.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="B":
                    self.btnB.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_B.show()
                    self.Mark_B.setText("Correct!")
                    ansstring=correct
            except:
                pass            
        elif Answer == "C":
            self.btnC.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="C":
                    self.btnC.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_C.show()
                    self.Mark_C.setText("Correct!")
                    ansstring=correct
            except:
                pass
        elif Answer == "D":
            self.btnD.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="D":
                    self.btnD.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_D.show()
                    self.Mark_D.setText("Correct!")
                    ansstring=correct
            except:
                pass

    #    if Answer == selectedanswer:
    #        self.Mark_A.show()
    #        self.Mark_D.setPixmap(correct_img)
    #    else:
    #        self.Mark_A.show()
    #        self.Mark_D.setPixmap(incorrect_img)
        
        self.setHintText()
    
    def QuestionReset(self):
        self.buttonReset()
        self.HintAnsLabel.hide()
        self.hideAnsImages()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        timenow=datetime.datetime.now()
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        try:
            radeotlog.write(tn + " " + question+" " + ansstring + '\n')
            radeotlog.close()
        except:
            pass
        self.setQuestion()

    def hideAnsImages(self):
        self.Mark_A.hide()
        self.Mark_B.hide()
        self.Mark_C.hide()
        self.Mark_D.hide()
########################################################### Toolbar Functions ################################################################
    def home_window(self):
        os.chdir(BASE_DIR)
        self.close()
        os.system('python3 runradeot.py')
        #self.switch_window.emit(1)
    def back_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex - 1
        if changeTab >= 0:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(4)
    def forward_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex + 1
        if changeTab <= 4:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(0)    
    def reload_window(self):
        os.chdir(BASE_DIR)
        self.switch_window.emit(0)
    def help_info(self):
        buttonReply = QMessageBox.question(self, 'Help Information - Radio', 
                                                    "Use the tabs to click through different activities\nor take a quiz to build your radio frequency knowledge!",
                                                        QMessageBox.Ok)
    def buildRadeot(self):
        os.chdir(BASE_DIR)
        file = ['okular','/home/pi/Documents/Scripts/BuildRadeot.pdf']
        filesp=subprocess.Popen(file)#,shell=True)
    def close_application(self):
        choice = QMessageBox.question(self,'Exit',
                                            "Do you really want to quit RadEOT?",
                                             QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass

class RadioDBWindow(QtWidgets.QMainWindow, Ui_RadioDBWindow):
    switch_window = QtCore.pyqtSignal(int)

    def __init__(self, parent=None):
        super(RadioDBWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('Listen to Radio')
        self.showMaximized()
        os.chdir(Imagepath)

        self.setWindowIcon(QIcon('Rlogo.png'))
        # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(Buttonpath, 'homeBlue2.png')), 'Home', self)
        homeAct.setToolTip('Go home - pick a new activity')
        homeAct.triggered.connect(self.home_window) 
        # Back button #
        backAct = QAction(QIcon(os.path.join(Buttonpath, 'backBlue2.png')), 'Back', self)
        backAct.setToolTip('Back')
        backAct.triggered.connect(self.back_window)
        # Forward #
        forwardAct = QAction(QIcon(os.path.join(Buttonpath, 'forwardBlue2.png')), 'Forward', self)
        forwardAct.setToolTip('Forward')
        forwardAct.triggered.connect(self.forward_window)
        # Refresh #
        refreshAct = QAction(QIcon(os.path.join(Buttonpath, 'refreshBlue2.png')), 'Refresh', self)
        #refreshAct.triggered.connect = self.InfoWindow.show()

        # Help button #
        helpAct = QAction(QIcon(os.path.join(Buttonpath, 'helpBlue2.png')), 'Help', self)
        helpAct.setToolTip('Get help!')
        helpAct.triggered.connect(self.help_info)

        # Build button #
        buildAct = QAction(QIcon(os.path.join(Buttonpath, 'brick.png')), 'Build', self)
        buildAct.setToolTip('Learn how to build RadEOT')
        buildAct.triggered.connect(self.buildRadeot)

        exitAct = QAction(QIcon(os.path.join(Buttonpath, 'exitBlue2.png')), 'Exit', self)
        exitAct.setToolTip('Exit app')
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Back')
        self.toolbar.addAction(backAct)
        self.toolbar = self.addToolBar('Forward')
        self.toolbar.addAction(forwardAct)
        self.toolbar = self.addToolBar('Refresh')
        self.toolbar.addAction(refreshAct)
        self.toolbar = self.addToolBar('Help')
        self.toolbar.addAction(helpAct)
        self.toolbar = self.addToolBar('Build')
        self.toolbar.addAction(buildAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)

        os.chdir(BASE_DIR)

        self.hideAnsImages()
        self.setQuestion()
        self.helplabelfiller()
        self.setCurrentSliderValue()
        self.FreqSlider.valueChanged.connect(self.setCurrentSliderValue)        
        
        self.RadioStartbtn2.clicked.connect(self.launchgqrx)
        self.RadioStartbtn2_2.clicked.connect(self.radiodbreader)

    def radiodbreader(self):
        reader = pd.read_hdf('/home/pi/Documents/Scripts/db/database.h5')
        ffo = reader['ffrom'].astype(np.float)
        fto = reader['fto'].astype(np.float)
        de1 = reader['descr1']
        de2 = reader['descr2']
        s=''
        ftest= float(CurrentFreq)#1000000
        for i in range (0,len(ffo)):
            if ftest >= ffo[i] and ftest<=fto[i]:
                sstring=str(ftest)+ "MHz: " + str(de1[i]) + ' ' + str(de2[i])+"\n"
                s=s+ sstring
        self.FreqLabel_2.setText(s)

    def launchgqrx(self):
        global freq
        freq = int(1000000*float(CurrentFreq))
        confdir = '/home/pi/.config/gqrx/'
        freqfile=open(confdir+"ConfMaking/f.txt", "w")
        freqfile.write('\nfrequency='+str(freq)+'\n')
        freqfile.close()
        freqfns=['d.txt','f.txt','d2.txt']
        with open(confdir+'ConfMaking/new.conf', 'w') as outfile:
            for fname in freqfns:
                with open(confdir+'ConfMaking/'+fname) as infile:
                    outfile.write(infile.read())
                infile.close()                
        outfile.close()            
        procrp=subprocess.Popen(['gqrx', '-c', 'ConfMaking/new.conf'])
        timenow=datetime.datetime.now()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        logstring=tn+" Launched GQRX to frequency "+ str(CurrentFreq) + "MHz\n"
        radeotlog.write(logstring)
        radeotlog.close()
        
    def helplabelfiller(self):
        hlf=open("/home/pi/Documents/Scripts/txt/help-radio.txt", "r").readline()
        self.HelpLabel.setText(hlf)
        
    def setCurrentSliderValue(self):
        FreqNum = self.FreqSlider.value()
        FreqmHz = FreqNum / 1000
        global CurrentFreq
        CurrentFreq = str(FreqmHz)
        self.CurrentValueLabel.setText(CurrentFreq)                                                  

    def setQuestion(self):
        try:
            freqq = float(CurrentFreq)
        except:
            freqq = 91
        KS=' '
        global question
        questionlist = self.read_from_dbks(keystage_txt)
        questionliststr = [item for t in questionlist for item in t]
        question, optA, optB, optC, optD, Ans, Notes, KS, Dependencies = questionliststr
        global AnswerHint
        AnswerHint = Notes
        global Answer
        Answer = Ans
        freqw=freqq+1

        if Dependencies == 'frequency':
            question=question.format(freqq, freqw)

        try:
            self.NewQuestion.clicked.disconnect(self.QuestionReset)
        except:
            pass
        self.QuestionLabel.setText(question)
        self.Ans_A.setText(optA)
        self.Ans_B.setText(optB)
        self.Ans_C.setText(optC)
        self.Ans_D.setText(optD)
        self.btnA.clicked.connect(self.SelectionA)
        self.btnB.clicked.connect(self.SelectionB)
        self.btnC.clicked.connect(self.SelectionC)
        self.btnD.clicked.connect(self.SelectionD)
        self.Hint.clicked.connect(self.setHintText)
        self.ClearSelection.clicked.connect(self.buttonReset)
        try:
            self.SubmitSelection.clicked.connect(self.submitAns)
        except:
            pass
        self.NewQuestion.clicked.connect(self.QuestionReset)

    def read_from_dbks(self, keystage_txt):
        os.chdir(DBpath)
        conn = sqlite3.connect('question.db')
        c = conn.cursor()
        if keystage_txt == 'ks6':
            c.execute("SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM radio ORDER BY RANDOM() LIMIT 1;")
        else:
            ksno=keystage_txt[-1:]
            sqlitestring="SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM radio WHERE KS LIKE '%{}' ORDER BY RANDOM() LIMIT 1;".format(ksno)
            c.execute(sqlitestring)
        questionlist = c.fetchall()
        c.close()
        conn.close()
        return questionlist
        os.chdir(BASE_DIR)
       
    def SelectionA(self):
        self.btnA.setStyleSheet("QPushButton { background-color: blue}")
        self.btnB.setEnabled(False)
        self.btnC.setEnabled(False)
        self.btnD.setEnabled(False)
        global selectedanswer
        selectedanswer =  "A" 

    def SelectionB(self):
        self.btnB.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnC.setEnabled(False)
        self.btnD.setEnabled(False)  
        global selectedanswer
        selectedanswer =  "B" 

    def SelectionC(self):
        self.btnC.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnD.setEnabled(False) 
        global selectedanswer
        selectedanswer =  "C" 

    def SelectionD(self):
        self.btnD.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnC.setEnabled(False)
        global selectedanswer 
        selectedanswer =  "D" 

    def setHintText(self):
        global AnswerHint
        self.HintAnsLabel.setText(AnswerHint)
      #  self.HintAnsText.setReadOnly(True)
        self.HintAnsLabel.show()
    
    def buttonReset(self):
        self.btnA.setStyleSheet("QPushButton { background-color: black }")
        self.btnB.setStyleSheet("QPushButton { background-color: black }")
        self.btnC.setStyleSheet("QPushButton { background-color: black }")
        self.btnD.setStyleSheet("QPushButton { background-color: black }")
        self.btnA.setEnabled(True)
        self.btnB.setEnabled(True)
        self.btnC.setEnabled(True)
        self.btnD.setEnabled(True) 
        self.hideAnsImages()
        global selectedanswer 
        selectedanswer =  ""
    
    def submitAns(self):
       ## Create widget < Was going to add tick / cross images here ##
       # correct_img = QPixmap((os.path.join(Buttonpath, 'tick.png')))
       # incorrect_img = QPixmap((os.path.join(Buttonpath, 'cross.png')))
       # self.Mark_D.setPixmap(correct)
        global ansstring
        correct ="Correct!"
        incorrect = "Incorrect"
        ansstring=incorrect
        if Answer == "A":
            self.btnA.setStyleSheet("QPushButton { background-color: white; color: black }")
          #  self.Mark_A.show()
          #  self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="A":
                    self.btnA.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_A.show()
                    self.Mark_A.setText(correct)
                    ansstring=correct
            except:
                pass
        elif Answer =="B":
            self.btnB.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="B":
                    self.btnB.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_B.show()
                    self.Mark_B.setText("Correct!")
                    ansstring=correct
            except:
                pass            
        elif Answer == "C":
            self.btnC.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="C":
                    self.btnC.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_C.show()
                    self.Mark_C.setText("Correct!")
                    ansstring=correct
            except:
                pass
        elif Answer == "D":
            self.btnD.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="D":
                    self.btnD.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_D.show()
                    self.Mark_D.setText("Correct!")
                    ansstring=correct
            except:
                pass

    #    if Answer == selectedanswer:
    #        self.Mark_A.show()
    #        self.Mark_D.setPixmap(correct_img)
    #    else:
    #        self.Mark_A.show()
    #        self.Mark_D.setPixmap(incorrect_img)
        
        self.setHintText()
    
    def QuestionReset(self):
        self.buttonReset()
        self.HintAnsLabel.hide()
        self.hideAnsImages()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        timenow=datetime.datetime.now()
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        try:
            radeotlog.write(tn + " " + question+" " + ansstring + '\n')
            radeotlog.close()
        except:
            pass
        self.setQuestion()

    def hideAnsImages(self):
        self.Mark_A.hide()
        self.Mark_B.hide()
        self.Mark_C.hide()
        self.Mark_D.hide()
########################################################### Toolbar Functions ################################################################
    def home_window(self):
        os.chdir(BASE_DIR)
        self.close()
        os.system('python3 runradeot.py')
        #self.switch_window.emit(1)
        
    def back_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex - 1

        if changeTab >= 0:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(4)

    def forward_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex + 1

        if changeTab <= 4:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(0)
        
    def help_info(self):
        buttonReply = QMessageBox.question(self, 'Help Information - Radio', 
                                                    "Use the tabs to click through different activities\nor take a quiz to build your radio frequency knowledge!",
                                                        QMessageBox.Ok)
    def buildRadeot(self):
        os.chdir(BASE_DIR)
        file = ['okular','/home/pi/Documents/Scripts/BuildRadeot.pdf']
        filesp=subprocess.Popen(file)#,shell=True)

    def close_application(self):
        choice = QMessageBox.question(self,'Exit',
                                            "Do you really want to quit RadEOT?",
                                             QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass


class HlineWindow(QtWidgets.QMainWindow, Ui_HlineWindow):
    switch_window = QtCore.pyqtSignal(int)

    def __init__(self, parent=None):
        super(HlineWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('Listen to Radio')
        self.showMaximized()
        os.chdir(Imagepath)

        self.setWindowIcon(QIcon('Rlogo.png'))
        # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(Buttonpath, 'homeBlue2.png')), 'Home', self)
        homeAct.setToolTip('Go home - pick a new activity')
        homeAct.triggered.connect(self.home_window) 
        # Back button #
        backAct = QAction(QIcon(os.path.join(Buttonpath, 'backBlue2.png')), 'Back', self)
        backAct.setToolTip('Back')
        backAct.triggered.connect(self.back_window)
        # Forward #
        forwardAct = QAction(QIcon(os.path.join(Buttonpath, 'forwardBlue2.png')), 'Forward', self)
        forwardAct.setToolTip('Forward')
        forwardAct.triggered.connect(self.forward_window)
        # Refresh #
        refreshAct = QAction(QIcon(os.path.join(Buttonpath, 'refreshBlue2.png')), 'Refresh', self)
        #refreshAct.triggered.connect = self.InfoWindow.show()

        # Help button #
        helpAct = QAction(QIcon(os.path.join(Buttonpath, 'helpBlue2.png')), 'Help', self)
        helpAct.setToolTip('Get help!')
        helpAct.triggered.connect(self.help_info)

        # Build button #
        buildAct = QAction(QIcon(os.path.join(Buttonpath, 'brick.png')), 'Build', self)
        buildAct.setToolTip('Learn how to build RadEOT')
        buildAct.triggered.connect(self.buildRadeot)

        exitAct = QAction(QIcon(os.path.join(Buttonpath, 'exitBlue2.png')), 'Exit', self)
        exitAct.setToolTip('Exit app')
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Back')
        self.toolbar.addAction(backAct)
        self.toolbar = self.addToolBar('Forward')
        self.toolbar.addAction(forwardAct)
        self.toolbar = self.addToolBar('Refresh')
        self.toolbar.addAction(refreshAct)
        self.toolbar = self.addToolBar('Help')
        self.toolbar.addAction(helpAct)
        self.toolbar = self.addToolBar('Build')
        self.toolbar.addAction(buildAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)

        os.chdir(BASE_DIR)

        self.hideAnsImages()
        self.setQuestion()
        self.helplabelfiller()
        self.RadioStartbtn2_2.clicked.connect(self.UpdateHornValues)
        # self.plainTextEdit.setReadOnly(True)
        #os.chdir(RTLFMpath)

        # After each value change, slot "setCurrentSliderValue" will get invoked. 
        self.setCurrentSliderValue()
        self.FreqSlider.valueChanged.connect(self.setCurrentSliderValue)        
        self.setCurrentSliderValue2()
        self.FreqSlider_2.valueChanged.connect(self.setCurrentSliderValue2)
        self.setCurrentSliderValue3()
        self.FreqSlider_3.valueChanged.connect(self.setCurrentSliderValue3)
        
        self.RadioStartbtn2.clicked.connect(self.launchgqrx)

    def setCurrentSliderValue(self):
        FreqNum = self.FreqSlider.value()
        FreqmHz = FreqNum / 1000
        global CurrentFreq
        CurrentFreq = str(FreqmHz)
        self.CurrentValueLabel.setText(CurrentFreq) #'rtl_fm -f' + str(freq) + 'M -s 44100 -g 50 -l 0 - | aplay -t raw -r 44100 -c 1 -f S16_LE'
    def setCurrentSliderValue2(self):
        FreqNum = self.FreqSlider_2.value()
        FreqmHz = FreqNum / 1000
        global CurrentFreq
        CurrentFreq = str(FreqmHz)
        self.CurrentValueLabel_2.setText(CurrentFreq) #'rtl_fm -f' + str(freq) + 'M -s 44100 -g 50 -l 0 - | aplay -t raw -r 44100 -c 1 -f S16_LE'
    def setCurrentSliderValue3(self):
        GainNum = self.FreqSlider_3.value()
        GainNum = GainNum / 1000
        global CurrentGain
        CurrentGain = str(GainNum)
        self.CurrentValueLabel_3.setText(CurrentGain) #'rtl_fm -f' + str(freq) + 'M -s 44100 -g 50 -l 0 - | aplay -t raw -r 44100 -c 1 -f S16_LE'    
    def horncalculator(self):
        c = 3e8 # Speed of light
        #FreqNum =     
        
        # Allow user to define Gain and observed frequency
        freq_user = self.FreqSlider_2.value()*1e3 #float(input('Observed Frequency (GHz) = '))*1e9
        gain_user = self.FreqSlider_3.value()/1000 #float(input('Preferred Gain of Antenna (dBi) = '))
        
        timenow=datetime.datetime.now()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        logstring=tn+" Designed Horn Antenna for frequency "+ str(freq_user) + "Hz and Gain " + str(gain_user) + "\n"
        radeotlog.write(logstring)
        radeotlog.close()
        lambda_user = c/freq_user

        # Determine the waveguide measurements
        # a = broadest side of waveguide (width)
        # b = shortest side of waveguide (height)
        a = 0.8382*c/freq_user
        b = 0.3925*c/freq_user

        # Calculate minimum and maximum frequencies waveguide can be used for
        f_c = c/(2*a)
        f_max, f_min = 1.89*f_c, 1.25*f_c
        # Calculate all values using equations scrubbed from page inspection of
        # online calculator:
        # view-source:http://www.microwavetools.com/pyramidal-horn-calculator/
        rho_e = lambda_user*pow(10,(gain_user/10))/(2*math.pi*pow((2*math.pi),0.5))
        rho_h = lambda_user*10**(gain_user/5)/248.0502*(15.7489/(10**(gain_user/10)))
        a1 = lambda_user*pow(10,(gain_user/10))
        a1=a1/6.2832*pow((7.5195/(10**(gain_user/10))),0.5)
        b1 = lambda_user*pow((pow(10,(gain_user/10))/7.8745),0.5)
        P_E = (b1-b)*pow((pow((rho_e/b1),2)-0.25),0.5)
        P_H = (a1-a)*pow((pow((rho_h/a1),2)-0.25),0.5)

        return a, b, a1, b1, P_E, P_H, rho_e, rho_h

    def UpdateHornValues(self):
        #HelpLabel_2, 5, 4, 6, 10, 9, 12, 7
        try:
            a, b, a1, b1, p_E, p_H, rho_e, rho_h=self.horncalculator()
            if isinstance(p_E,complex):
                p_Ea = "Complex"
                self.FreqLabel_2.setText(p_Ea)
            else:
                self.FreqLabel_2.setText(str("{0:.3g}".format(p_E)))  #
            if isinstance(p_H,complex):
                p_Ha = "Complex"
                self.FreqLabel_13.setText(p_Ha)
            else:
                self.FreqLabel_13.setText(str("{0:.3g}".format(p_H))) #
            self.FreqLabel_9.setText(str("{0:.3g}".format(a)))
            self.FreqLabel_14.setText(str("{0:.3g}".format(b)))
            self.FreqLabel_6.setText(str("{0:.3g}".format(a1)))
            self.FreqLabel_10.setText(str("{0:.3g}".format(b1)))
            self.FreqLabel_19.setText(str("{0:.3g}".format(rho_e)))
            self.FreqLabel_17.setText(str("{0:.3g}".format(rho_h)))
        except:
            pass

    def launchgqrx(self):
        global freq
        freq = int(1000000*float(CurrentFreq))
        confdir = '/home/pi/.config/gqrx/'
        freqfile=open(confdir+"ConfMaking/f.txt", "w")
        freqfile.write('\nfrequency='+str(freq)+'\n')
        freqfile.close()
        freqfns=['d.txt','f.txt','d2.txt']
        with open(confdir+'ConfMaking/new.conf', 'w') as outfile:
            for fname in freqfns:
                with open(confdir+'ConfMaking/'+fname) as infile:
                    outfile.write(infile.read())
                infile.close()                
        outfile.close()            
        procrp=subprocess.Popen(['gqrx', '-c', 'ConfMaking/new.conf'])
        timenow=datetime.datetime.now()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        logstring=tn+" Launched GQRX to frequency "+ str(CurrentFreq) + "MHz\n"
        radeotlog.write(logstring)
        radeotlog.close()
        
    def helplabelfiller(self):
        hlf=open("/home/pi/Documents/Scripts/txt/help-hline.txt", "r").readline()
        self.HelpLabel.setText(hlf)

    # not in use rtl-sdr in folder in Scripts    os.chdir("/usr/local/bin/rtlfm")  

    ################################ Notes for rtl-sdr ########################################################
    # Use:    rtl_fm -f freq [-options] [filename]
    #   [-f frequency_to_tune_to [Hz]
    #        use multiple -f for scanning (requires squelch)
    #        ranges supported, -f 118M:137M:25k
    #    [-M modulation (default: fm)]
    #        fm, wbfm, raw, am, usb, lsb
    #        wbfm == -M fm -s 170k -o 4 -A fast -r 32k -l 0 -E deemp
    #        raw mode outputs 2x16 bit IQ pairs
    #    [-s sample_rate (default: 24k)]
    #    [-d device_index (default: 0)]
    #    [-T enable bias-T on GPIO PIN 0 (works for rtl-sdr.com v3 dongles)]
    #    [-g tuner_gain (default: automatic)]
    #    [-l squelch_level (default: 0/off)]
    #    [-p ppm_error (default: 0)]
    #    [-E enable_option (default: none)]
    #        use multiple -E to enable multiple options
    #        edge:   enable lower edge tuning
    #        dc:     enable dc blocking filter
    #        deemp:  enable de-emphasis filter
    #        direct: enable direct sampling
    #        offset: enable offset tuning
    #    filename ('-' means stdout)
    #        omitting the filename also uses stdout

    # Experimental options:
    #    [-r resample_rate (default: none / same as -s)]
    #    [-t squelch_delay (default: 10)]
    #        +values will mute/scan, -values will exit
    #    [-F fir_size (default: off)]
    #        enables low-leakage downsample filter
    #        size can be 0 or 9.  0 has bad roll off
    #    [-A std/fast/lut choose atan math (default: std)]

    # Produces signed 16 bit ints, use Sox or aplay to hear them.
    #    rtl_fm ... | play -t raw -r 24k -es -b 16 -c 1 -V1 -
    #               | aplay -r 24k -f S16_LE -t raw -c 1 
    #      -M wbfm  | play -r 32k ...
    #      -s 22050 | multimon -t raw /dev/stdin    
    #############################################################################################################
    # To sample reception of  all commercial wide-band FM signals   use .....
    # rtl_fm -f 96.3e6 -M wbfm -s 200000 -r 48000 - | aplay -r 48k -f S16_LE
                                                           
    def setQuestion(self):
        KS=' '
        global question
        questionlist = self.read_from_dbks(keystage_txt)
        questionliststr = [item for t in questionlist for item in t]
        question, optA, optB, optC, optD, Ans, Notes, KS, Dependencies = questionliststr
        global AnswerHint
        AnswerHint = Notes
        global Answer
        Answer = Ans

      #  self.Question.setReadOnly(True)
        if Dependencies == 'redshift':
            redshift=random.randint(1,101)/10
            redshifta='z='+str(redshift)
            question=question.format(redshifta)
            optA=str("{0:.5g}".format(eval(optA.format(redshift))))+' Hz'
            optB=str("{0:.5g}".format(eval(optB.format(redshift))))+' Hz'
            optC=str("{0:.5g}".format(eval(optC.format(redshift))))+' Hz'
            optD=str("{0:.5g}".format(eval(optD.format(redshift))))+' Hz'
        if Dependencies == 'e':
            e=1.6*pow(10,-19)
            epsilon=8.85*pow(10,-12)
            r=52*pow(10,-12)
            optA=str("{0:.5g}".format(eval(optA.format(e,e,epsilon,r,r))))+' J'
            optB=str("{0:.5g}".format(eval(optB.format(e,epsilon,r,r))))+' J'
            optC=str("{0:.5g}".format(eval(optC.format(e,e,r,r))))+' J'
            optD=str("{0:.5g}".format(eval(optD.format(e,e,epsilon,r))))+' J'
                 
        try:
            self.NewQuestion.clicked.disconnect(self.QuestionReset)
        except:
            pass
        self.QuestionLabel.setText(question)
        self.Ans_A.setText(optA)
        self.Ans_B.setText(optB)
        self.Ans_C.setText(optC)
        self.Ans_D.setText(optD)
        self.btnA.clicked.connect(self.SelectionA)
        self.btnB.clicked.connect(self.SelectionB)
        self.btnC.clicked.connect(self.SelectionC)
        self.btnD.clicked.connect(self.SelectionD)
        self.Hint.clicked.connect(self.setHintText)
        self.ClearSelection.clicked.connect(self.buttonReset)
        try:
            self.SubmitSelection.clicked.connect(self.submitAns)
        except:
            pass
        self.NewQuestion.clicked.connect(self.QuestionReset)

    def read_from_dbks(self, keystage_txt):
        os.chdir(DBpath)
        conn = sqlite3.connect('question.db')
        c = conn.cursor()
        if keystage_txt == 'ks6':
            c.execute("SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM hline ORDER BY RANDOM() LIMIT 1;")
        else:
            ksno=keystage_txt[-1:]
            sqlitestring="SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM hline WHERE KS LIKE '%{}' ORDER BY RANDOM() LIMIT 1;".format(ksno)
            c.execute(sqlitestring)
        questionlist = c.fetchall()
        c.close()
        conn.close()
        return questionlist
        os.chdir(BASE_DIR)

    def SelectionA(self):
        self.btnA.setStyleSheet("QPushButton { background-color: blue}")
        self.btnB.setEnabled(False)
        self.btnC.setEnabled(False)
        self.btnD.setEnabled(False)
        global selectedanswer
        selectedanswer =  "A" 

    def SelectionB(self):
        self.btnB.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnC.setEnabled(False)
        self.btnD.setEnabled(False)  
        global selectedanswer
        selectedanswer =  "B" 

    def SelectionC(self):
        self.btnC.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnD.setEnabled(False) 
        global selectedanswer
        selectedanswer =  "C" 

    def SelectionD(self):
        self.btnD.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnC.setEnabled(False)
        global selectedanswer 
        selectedanswer =  "D" 

    def setHintText(self):
        global AnswerHint
        self.HintAnsLabel.setText(AnswerHint)
      #  self.HintAnsText.setReadOnly(True)
        self.HintAnsLabel.show()
    
    def buttonReset(self):
        self.btnA.setStyleSheet("QPushButton { background-color: black }")
        self.btnB.setStyleSheet("QPushButton { background-color: black }")
        self.btnC.setStyleSheet("QPushButton { background-color: black }")
        self.btnD.setStyleSheet("QPushButton { background-color: black }")
        self.btnA.setEnabled(True)
        self.btnB.setEnabled(True)
        self.btnC.setEnabled(True)
        self.btnD.setEnabled(True) 
        self.hideAnsImages()
        global selectedanswer 
        selectedanswer =  ""
    
    def submitAns(self):
       ## Create widget < Was going to add tick / cross images here ##
       # correct_img = QPixmap((os.path.join(Buttonpath, 'tick.png')))
       # incorrect_img = QPixmap((os.path.join(Buttonpath, 'cross.png')))
       # self.Mark_D.setPixmap(correct)
        global ansstring
        correct ="Correct!"
        incorrect = "Incorrect"
        ansstring=incorrect
        if Answer == "A":
            self.btnA.setStyleSheet("QPushButton { background-color: white; color: black }")
          #  self.Mark_A.show()
          #  self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="A":
                    self.btnA.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_A.show()
                    self.Mark_A.setText(correct)
                    ansstring=correct
            except:
                pass
        elif Answer =="B":
            self.btnB.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="B":
                    self.btnB.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_B.show()
                    self.Mark_B.setText("Correct!")
                    ansstring=correct
            except:
                pass            
        elif Answer == "C":
            self.btnC.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="C":
                    self.btnC.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_C.show()
                    self.Mark_C.setText("Correct!")
                    ansstring=correct
            except:
                pass
        elif Answer == "D":
            self.btnD.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="D":
                    self.btnD.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_D.show()
                    self.Mark_D.setText("Correct!")
                    ansstring=correct
            except:
                pass

    #    if Answer == selectedanswer:
    #        self.Mark_A.show()
    #        self.Mark_D.setPixmap(correct_img)
    #    else:
    #        self.Mark_A.show()
    #        self.Mark_D.setPixmap(incorrect_img)
        
        self.setHintText()
    
    def QuestionReset(self):
        self.buttonReset()
        self.HintAnsLabel.hide()
        self.hideAnsImages()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        timenow=datetime.datetime.now()
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        try:
            radeotlog.write(tn + " " + question+" " + ansstring + '\n')
            radeotlog.close()
        except:
            pass
        self.setQuestion()

    def hideAnsImages(self):
        self.Mark_A.hide()
        self.Mark_B.hide()
        self.Mark_C.hide()
        self.Mark_D.hide()
########################################################### Toolbar Functions ################################################################
    def home_window(self):
        os.chdir(BASE_DIR)
        self.close()
        os.system('python3 runradeot.py')
        #self.switch_window.emit(1)

    def back_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex - 1
        if changeTab >= 0:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(4)

    def forward_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex + 1
        if changeTab <= 4:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(0)
        
    def help_info(self):
        buttonReply = QMessageBox.question(self, 'Help Information - Radio', 
                                                    "Use the tabs to click through different activities\nor take a quiz to build your radio frequency knowledge!",
                                                        QMessageBox.Ok)
    def buildRadeot(self):
        os.chdir(BASE_DIR)
        file = ['okular','/home/pi/Documents/Scripts/BuildRadeot.pdf']
        filesp=subprocess.Popen(file)#,shell=True)

    def close_application(self):
        choice = QMessageBox.question(self,'Exit',
                                            "Do you really want to quit RadEOT?",
                                             QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass

class flightWindow(QtWidgets.QMainWindow, Ui_FlightHackerWindow):
    switch_window = QtCore.pyqtSignal(int)

    def __init__(self, parent=None):
        super(flightWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('Track some planes!')
        self.setWindowIcon(QIcon('Rlogo.png'))
        self.showMaximized()
        os.chdir(Imagepath)

        self.setWindowIcon(QIcon('Rlogo.png'))
        # Toolbar #
        # Home button #
        homeAct = QAction(QIcon(os.path.join(Buttonpath, 'homeBlue2.png')), 'Home', self)
        homeAct.setToolTip('Go home - pick a new activity')
        homeAct.triggered.connect(self.home_window) 
        # Back button #
        backAct = QAction(QIcon(os.path.join(Buttonpath, 'backBlue2.png')), 'Back', self)
        backAct.setToolTip('Back')
        backAct.triggered.connect(self.back_window)
        # Forward #
        forwardAct = QAction(QIcon(os.path.join(Buttonpath, 'forwardBlue2.png')), 'Forward', self)
        forwardAct.setToolTip('Forward')
        forwardAct.triggered.connect(self.forward_window)
        # Refresh #
        refreshAct = QAction(QIcon(os.path.join(Buttonpath, 'refreshBlue2.png')), 'Refresh', self)
        #refreshAct.triggered.connect = self.InfoWindow.show()
        # Help button #
        helpAct = QAction(QIcon(os.path.join(Buttonpath, 'helpBlue2.png')), 'Help', self)
        helpAct.setToolTip('Get help!')
        helpAct.triggered.connect(self.help_info)
        # Build button #
        buildAct = QAction(QIcon(os.path.join(Buttonpath, 'brick.png')), 'Build', self)
        buildAct.setToolTip('Learn how to build RadEOT')
        buildAct.triggered.connect(self.buildRadeot)

        exitAct = QAction(QIcon(os.path.join(Buttonpath, 'exitBlue2.png')), 'Exit', self)
        exitAct.setToolTip('Exit app')
        exitAct.setShortcut('Ctrl+Q')
        exitAct.triggered.connect(self.close_application)

        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(homeAct)
        self.toolbar = self.addToolBar('Back')
        self.toolbar.addAction(backAct)
        self.toolbar = self.addToolBar('Forward')
        self.toolbar.addAction(forwardAct)
        self.toolbar = self.addToolBar('Refresh')
        self.toolbar.addAction(refreshAct)
        self.toolbar = self.addToolBar('Help')
        self.toolbar.addAction(helpAct)
        self.toolbar = self.addToolBar('Build')
        self.toolbar.addAction(buildAct)
        self.toolbar = self.addToolBar('Exit')
        self.toolbar.addAction(exitAct)
        try:
            AddrList = self.uniqueflightfinder()
            TimeList = self.flighttimes().values.tolist()
            self.SelectPlane.addItems(AddrList)
            self.SelectTime.addItems(TimeList)
        except:
            AddrList=['No Data Available']
            TimeList=['No Data Available']
            self.SelectPlane.addItems(AddrList)
            self.SelectTime.addItems(TimeList)
        self.TrackLaunchbtn_2.clicked.connect(self.UpdateFlightValues)
        self.TrackLaunchbtn_3.clicked.connect(self.UpdatePlanes)    
        os.chdir(BASE_DIR)
        self.hideAnsImages()     
        self.setQuestion()
        self.helplabelfiller()
        self.TrackLaunchbtn.clicked.connect(self.launchtracker)
        
    def UpdatePlanes(self):
        try:
            AddrList = self.uniqueflightfinder()
            TimeList = self.flighttimes().values.tolist()
            self.SelectPlane.clear()
            self.SelectTime.clear()
            self.SelectPlane.addItems(AddrList)
            self.SelectTime.addItems(TimeList)
        except:
            AddrList=['No Data Available']
            TimeList=['No Data Available']
            self.SelectPlane.addItems(AddrList)
            self.SelectTime.addItems(TimeList)

    def planesreader(self):
        lepddir='/home/pi/Documents/PlaneTracker/planes.h5'
        reader=pd.read_hdf(lepddir)
        currentflight = str(self.SelectPlane.currentText())
        currenttime = str(self.SelectTime.currentText())
        readerplane=reader.loc[reader['addr']==currentflight]
        readerplane=readerplane.loc[readerplane['dateandtime'].dt.strftime('%Y-%m-%d %H:%M:%S:%f') == currenttime]
        global speed
        speed=readerplane['speed'].values[0]
        heading=readerplane['heading'].values[0]
        lat=readerplane['lat'].values[0]
        lon=readerplane['lon'].values[0]
        rot=readerplane['rotation'].values[0]
        alt=readerplane['altitude'].values[0]
        category=readerplane['category'].values[0]
        callsign=readerplane['callsign'].values[0]
        return speed, heading, lat, lon, rot, alt, category, callsign

    
    def UpdateFlightValues(self):
        #HelpLabel_2, 5, 4, 6, 10, 9, 12, 7
        try:
            speed, heading, lat, lon, rot, alt, category, callsign = self.planesreader()
            if "Series" in str(speed):
                speed='-'
            self.HelpLabel_2.setText(str(speed)+' knots')
            if "Series" in str(heading):
                heading='-'
            try:
                self.HelpLabel_5.setText(str(heading)[:6])
            except:
                self.HelpLabel_5.setText(str(heading))
            if "Series" in str(lat):
                lat='-'
            try:
                self.HelpLabel_4.setText(str(lat)[:6])
            except:
                self.HelpLabel_4.setText(str(lat))
            if "Series" in str(lon):
                lon='-'
            try:
                self.HelpLabel_6.setText(str(lon)[:6])
            except:
                self.HelpLabel_6.setText(str(lon))
            if "Series" in str(rot):
                rot='-'        
            try:
                self.HelpLabel_10.setText(str(rot)[:6])
            except:
                self.HelpLabel_10.setText(str(rot))
            if "Series" in str(alt):
                alt='-'
            self.HelpLabel_9.setText(str(alt)+' feet')
            if "Series" in str(category):
                category='-'
            self.HelpLabel_12.setText(str(category))
            if "Series" in str(callsign):
                callsign='-'
            self.HelpLabel_7.setText(str(callsign))
        except:
            speed='No Data Available'
            self.HelpLabel_2.setText(str(speed))
            heading='No Data Available'
            self.HelpLabel_5.setText(str(heading))
            lat='No Data Available'
            self.HelpLabel_4.setText(str(lat))
            lon='No Data Available'
            self.HelpLabel_6.setText(str(lon))
            rot='No Data Available'
            self.HelpLabel_10.setText(str(rot))
            alt='No Data Available'
            self.HelpLabel_9.setText(str(alt))
            category='No Data Available'
            self.HelpLabel_12.setText(str(category))
            callsign='No Data Available'
            self.HelpLabel_7.setText(str(callsign))
   
    def uniqueflightfinder(self):
        lepddir='/home/pi/Documents/PlaneTracker/planes.h5'
        planes=pd.read_hdf(lepddir).addr.unique()
        return planes
    
    def flighttimes(self):
        lepddir='/home/pi/Documents/PlaneTracker/planes.h5'
        times = pd.read_hdf(lepddir)['dateandtime'].dt.strftime('%Y-%m-%d %H:%M:%S:%f')
        return times

    def launchtracker(self):
        try:
            c=str(check_output('netstat -tupln | grep 5006', shell=True)).split()
            d=['/python']
            e=[s for s in c if any(xs in s for xs in d)][0].split('/')[0]
            killstring='kill -9 ' + e
            os.system(killstring) 
        except:
            pass
        try:
            c=str(check_output('netstat -tupln | grep 8080', shell=True)).split()
            d=['/sdr_adsb']
            e=[s for s in c if any(xs in s for xs in d)][0].split('/')[0]
            killstring='kill -9 ' + e
            os.system(killstring) 
        except:
            pass
        planetrackdir='/home/pi/Documents/PlaneTracker'
        os.chdir(planetrackdir)
        timenow=datetime.datetime.now()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        logstring=tn+" Tracking Planes!\n"
        radeotlog.write(logstring)
        radeotlog.close()
        bokehcommand='python3 -m bokeh serve sdr_adsb --show --unused-session-lifetime 100 --check-unused-sessions 10'
        os.system(bokehcommand)

    def doSomething(self):
        self.switch_window.emit()

    def setQuestion(self):
        try:
            velocity, bearing, lat, lon, rotation, altitude, category, callsign = self.planesreader()
            velocity=velocity*1.852 #knots to km/hr
            altitude=0.3*altitude/1000 #ft to km
            transponder='4010EA'
        except:
            velocity=200+50*(random.randint(1,6))
            altitude=random.randint(25,35)
            bearing=random.randint(0,360)
            transponder='4010EA'
            rotation=random.randint(0,100)/100   
        KS=' '
        global question
        questionlist = self.read_from_dbks(keystage_txt)
        questionliststr = [item for t in questionlist for item in t]
        question, optA, optB, optC, optD, Ans, Notes, KS, Dependencies = questionliststr
        global AnswerHint
        AnswerHint = Notes
        global Answer
        Answer = Ans

        if Dependencies == 'velocity':
            question=question.format(velocity)
            optA=str("{0:.4g}".format(eval(optA.format(velocity))))
            optB=str("{0:.4g}".format(eval(optB.format(velocity))))
            optC=str("{0:.4g}".format(eval(optC.format(velocity))))
            optD=str("{0:.4g}".format(eval(optD.format(velocity))))
        if Dependencies == 'KTL':
            optA=eval(optA)
            optB=eval(optB)
            optC=eval(optC)
            optD=eval(optD)
        if Dependencies == 'rotation':
            rotation=float(round(rotation,4))
            question=question.format(rotation)
            optA=str("{0:.4g}".format(eval(optA.format(rotation))))
            optB=str("{0:.4g}".format(eval(optB.format(rotation))))
            optC=str("{0:.4g}".format(eval(optC.format(rotation))))
            optD=str("{0:.4g}".format(eval(optD.format(rotation))))
        if Dependencies == 'altitude':
            question=question.format(altitude)
            optA=str("{0:.4g}".format(eval(optA.format(altitude))))
            optB=str("{0:.4g}".format(eval(optB.format(altitude))))
            optC=str("{0:.4g}".format(eval(optC.format(altitude))))
            optD=str("{0:.4g}".format(eval(optD.format(altitude))))
        if Dependencies == 'Bearing, Velocity':
            #bearing=float(str("{0:.4g}".format(str(bearing))))
            question=question.format(bearing, velocity,velocity)
            optA=str("{0:.4g}".format(eval(optA.format(velocity,bearing,bearing))))
            optB=str("{0:.4g}".format(eval(optB.format(velocity,bearing,bearing))))
            optC=str("{0:.4g}".format(eval(optC.format(velocity,bearing,bearing))))
            optD=str("{0:.4g}".format(eval(optD.format(velocity,bearing,bearing))))
        try:
            self.NewQuestion.clicked.disconnect(self.QuestionReset)
        except:
            pass
        self.QuestionLabel.setText(question)
        self.Ans_A.setText(optA)
        self.Ans_B.setText(optB)
        self.Ans_C.setText(optC)
        self.Ans_D.setText(optD)
        self.btnA.clicked.connect(self.SelectionA)
        self.btnB.clicked.connect(self.SelectionB)
        self.btnC.clicked.connect(self.SelectionC)
        self.btnD.clicked.connect(self.SelectionD)
        self.Hint.clicked.connect(self.setHintText)
        self.ClearSelection.clicked.connect(self.buttonReset)
        try:
            self.SubmitSelection.clicked.connect(self.submitAns)
        except:
            pass
        self.NewQuestion.clicked.connect(self.QuestionReset)

    def read_from_dbks(self, keystage_txt):
        os.chdir(DBpath)
        conn = sqlite3.connect('question.db')
        c = conn.cursor()
        if keystage_txt == 'ks6':
            c.execute("SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM flight ORDER BY RANDOM() LIMIT 1;")
        else:
            ksno=keystage_txt[-1:]
            sqlitestring="SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Notes, KS, Dependencies FROM flight WHERE KS LIKE '%{}' ORDER BY RANDOM() LIMIT 1;".format(ksno)
            c.execute(sqlitestring)
        questionlist = c.fetchall()
        c.close()
        conn.close()
        return questionlist
        os.chdir(BASE_DIR)
       
    def SelectionA(self):
        try:
            self.btnA.setStyleSheet("QPushButton { background-color: blue}")
            self.btnB.setEnabled(False)
            self.btnC.setEnabled(False)
            self.btnD.setEnabled(False)
            global selectedanswer
            selectedanswer =  "A"
        except:
            pass

    def SelectionB(self):
        self.btnB.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnC.setEnabled(False)
        self.btnD.setEnabled(False)  
        global selectedanswer
        selectedanswer =  "B" 

    def SelectionC(self):
        self.btnC.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnD.setEnabled(False) 
        global selectedanswer
        selectedanswer =  "C" 

    def SelectionD(self):
        self.btnD.setStyleSheet("QPushButton { background-color: blue}")
        self.btnA.setEnabled(False)
        self.btnB.setEnabled(False)
        self.btnC.setEnabled(False)
        global selectedanswer 
        selectedanswer =  "D" 

    def setHintText(self):
        global AnswerHint
        self.HintAnsLabel.setText(AnswerHint)
      #  self.HintAnsText.setReadOnly(True)
        self.HintAnsLabel.show()
    
    def buttonReset(self):
        self.btnA.setStyleSheet("QPushButton { background-color: black }")
        self.btnB.setStyleSheet("QPushButton { background-color: black }")
        self.btnC.setStyleSheet("QPushButton { background-color: black }")
        self.btnD.setStyleSheet("QPushButton { background-color: black }")
        self.btnA.setEnabled(True)
        self.btnB.setEnabled(True)
        self.btnC.setEnabled(True)
        self.btnD.setEnabled(True) 
        self.hideAnsImages()
        global selectedanswer 
        selectedanswer =  ""
    
    def submitAns(self):
       ## Create widget < Was going to add tick / cross images here ##
       # correct_img = QPixmap((os.path.join(Buttonpath, 'tick.png')))
       # incorrect_img = QPixmap((os.path.join(Buttonpath, 'cross.png')))
       # self.Mark_D.setPixmap(correct)
        global ansstring
        correct ="Correct!"
        incorrect = "Incorrect"
        ansstring=incorrect
        if Answer == "A":
            self.btnA.setStyleSheet("QPushButton { background-color: white; color: black }")
          #  self.Mark_A.show()
          #  self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="A":
                    self.btnA.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_A.show()
                    self.Mark_A.setText(correct)
                    ansstring=correct
            except:
                pass
        elif Answer =="B":
            self.btnB.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="B":
                    self.btnB.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_B.show()
                    self.Mark_B.setText("Correct!")
                    ansstring=correct
            except:
                pass            
        elif Answer == "C":
            self.btnC.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnD.setStyleSheet("QPushButton { background-color: red }")
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="C":
                    self.btnC.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_C.show()
                    self.Mark_C.setText("Correct!")
                    ansstring=correct
            except:
                pass
        elif Answer == "D":
            self.btnD.setStyleSheet("QPushButton { background-color: white; color: black }")
            #self.Mark_A.setPixmap(tick)
            self.btnA.setStyleSheet("QPushButton { background-color: red }")
            self.btnB.setStyleSheet("QPushButton { background-color: red }")
            self.btnC.setStyleSheet("QPushButton { background-color: red }")
            try:
                if selectedanswer =="D":
                    self.btnD.setStyleSheet("QPushButton { background-color: green }")
                    self.Mark_D.show()
                    self.Mark_D.setText("Correct!")
                    ansstring=correct
            except:
                pass
        #    if Answer == selectedanswer:
        #        self.Mark_A.show()
        #        self.Mark_D.setPixmap(correct_img)
        #    else:
        #        self.Mark_A.show()
        #        self.Mark_D.setPixmap(incorrect_img)
            
            self.setHintText()
        #except:
        #    pass
    def QuestionReset(self):
        self.buttonReset()
        self.HintAnsLabel.hide()
        self.hideAnsImages()
        radeotlog=open("/home/pi/Desktop/RadEOTuserlog.txt", "a")
        timenow=datetime.datetime.now()
        tn=timenow.strftime("%d/%m/%Y %H:%M:%S")
        try:
            radeotlog.write(tn + " " + question+" " + ansstring + '\n')
            radeotlog.close()
        except:
            pass
        self.setQuestion()

    def hideAnsImages(self):
        self.Mark_A.hide()
        self.Mark_B.hide()
        self.Mark_C.hide()
        self.Mark_D.hide()
        
    def helplabelfiller(self):
        hlf=open("/home/pi/Documents/Scripts/txt/help-aircraft.txt", "r").readline()
        self.HelpLabel.setText(hlf)
        
########################################################### Toolbar Functions ################################################################
    def home_window(self):
        os.chdir(BASE_DIR)
        self.close()
        os.system('python3 runradeot.py')
        #self.switch_window.emit(1)
    def back_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex - 1
        if changeTab >= 0:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(4)

    def forward_window(self):
        currentIndex=self.tabWidget.currentIndex()
        changeTab = currentIndex + 1

        if changeTab <= 4:
            self.tabWidget.setCurrentIndex(changeTab)
        else: 
            self.tabWidget.setCurrentIndex(0)
        
    def help_info(self):
        buttonReply = QMessageBox.question(self, 'Help Information - Radio', 
                                                    "Use the tabs to click through different activities\nor take a quiz to build your radio frequency knowledge!",
                                                        QMessageBox.Ok)
    def buildRadeot(self):
        os.chdir(BASE_DIR)
        file = ['okular','/home/pi/Documents/Scripts/BuildRadeot.pdf']
        filesp=subprocess.Popen(file)#,shell=True)

    def close_application(self):
        choice = QMessageBox.question(self,'Exit',
                                            "Do you really want to quit RadEOT?",
                                             QMessageBox.Yes | QMessageBox.No)
        if choice == QMessageBox.Yes:
            print("Thank you for using RadEOT")
            sys.exit()
        else:
            pass


f=open("/home/pi/Documents/Scripts/settingsconf.txt", "r")
bkgcol=str(f.readline())[:-1]
col=str(f.readline())
if col!=bkgcol:
    qw =  '''
    QWidget {
        background-color: %s;
        color: %s;
        font-size: 18px;
    }''' % (bkgcol, col)
    ql =  '''
    QLabel {
        background-color: %s;
        font: Lucida Console;
        font-size: 18px;
        color: %s;
    }''' % (bkgcol, col)
    qcb = '''
    QComboBox {
        background-color: %s; 
        color: %s; 
        font-size: 18px;
    } ''' % (bkgcol, col)
    qpbp='''
    QPushButton:pressed { 
        background-color: white 
    } '''
    pb = '''
    PushButton {
    background-color: %s; 
    color: %s; 
    font-size: 18px;
    }  ''' % (bkgcol, col)
    qpbh='''
    QPushButton:hover {
        background-color: %s; 
        color: darkgrey;
        font-size: 20px;
    }''' % bkgcol    
    qmb = '''
    QMessageBox {
        background-color: %s; 
        color: %s; 
        font-size: 18px;
    }  ''' % (bkgcol, col)
    qt = '''
    QTextEdit {
    background-color: %s; 
    color: %s; 
    font-size: 18px; 
    border: 0;
    } ''' % (bkgcol, col)
    qs='''
    QSlider {
    background-color: %s; 
    color: %s; 
    font-size: 18px; 
    border: 0;
    }''' % (bkgcol, col)
    qtw='''
    QTabWidget {
    background-color: %s; 
    color: %s; 
    font-size: 14px; 
    }''' % (bkgcol, col)
    qtb =  '''  
    QTabBar {
    background-color: white; 
    color: black; 
    font-size: 14px; 
    }
    '''
    style = qw+ql+qcb+qpbp+pb+qpbh+qmb+qt+qs+qtw+qtb
else:
    style = '''
    QWidget {
        background-color: black;
        color: white; 
        font-size: 18px;
    } 

    QLabel {
        background-color: black;
        font: Lucida Console; 
        font-size: 18px;
        color: white; 
    }      

    QComboBox {
        background-color: black; 
        color: white; 
        font-size: 18px;
    }

    PushButton {
        background-color: black; 
        color: white; 
        font-size: 18px;
    }
        
    QPushButton:hover {
        background-color: black; 
        color: darkgrey;
        font-size: 20px;
    }
    QPushButton:pressed { 
        background-color: white 
    }

    QMessageBox {
        background-color: 
        black; 
        color: white; 
        font-size: 18px;
    } 

    QTextEdit {
    background-color: black; 
    color: white; 
    font-size: 18px; 
    border: 0;
    }

    QSlider {
    background-color: black; 
    color: white; 
    font-size: 18px; 
    border: 0;
    }

    QTabWidget {
    background-color: black; 
    color: white; 
    font-size: 14px; 
    }
    QTabBar {
    background-color: white; 
    color: black; 
    font-size: 14px; 
    }
    '''

class Controller:

    def __init__(self):
        pass

    def show_EnterRadeot(self):
## index relates to the switch window controller 0 = refresh, 1 = home, 2 = back, 3 = next window/forward ###
        self.window = RWindow()
        self.window.switch_window.connect(self.show_SelectWindow)
        self.window.show()

    def show_SelectWindow(self):
        gif ="Hard"
        self.SelectWindow = MoviePlayer(gif, "Select an Activity")

        self.SelectWindow.switch_window.connect(self.show_KSWindow)
        self.window.close()
        self.SelectWindow.show()

    def show_KSWindow(self):
        #self.KSWindow = KSWindow()
        self.SelectWindow.close()
        if activity_key == 'securearea':
            self.determine_InfoNextWindow(3)
        else:
            self.KSWindow = KSWindow()
            self.KSWindow.show()
            self.KSWindow.switch_window.connect(self.determine_KSNextWindow)
    
    def determine_KSNextWindow(self, ChangeWindowIndex):
        if ChangeWindowIndex == 0:
            #self.KSWindow.switch_window.connect(self.show_KSWindow)
            self.show_KSWindow() 
        if ChangeWindowIndex == 1:
            self.KSWindow.close()
            self.show_EnterRadeot()  
        if ChangeWindowIndex == 2:
            self.KSWindow.close() 
            self.show_SelectWindow()
        if ChangeWindowIndex == 3:
            self.show_InfoWindow()
        if ChangeWindowIndex == 4:
            self.RadioWindow.close()
            self.show_EnterRadeot()            

    def show_InfoWindow(self):
        self.InfoWindow = InfoWindow()
      # gif = activity_key
      # self.InfoWindow = MoviePlayer2(gif, "RadEOT")
        self.KSWindow.close()
        self.InfoWindow.show()
        self.InfoWindow.switch_window.connect(self.determine_InfoNextWindow)

    def determine_InfoNextWindow(self, ChangeWindowIndex):
        if ChangeWindowIndex == 0:
        #    self.KSWindow.switch_window.connect(self.show_InfoWindow)
            self.show_InfoWindow()
        if ChangeWindowIndex == 1:
            self.InfoWindow.close()
            self.show_SelectWindow()    
        if ChangeWindowIndex == 2:
            self.InfoWindow.close() 
            self.show_KSWindow()
        if ChangeWindowIndex == 3:
        #    self.KSWindow.switch_window.connect(self.show_InfoWindow)
            try:
                self.InfoWindow.close()
            except:
                pass
            if activity_key=="flighthacker":
                self.StartFlight()
            elif activity_key=='radio':
                self.show_RadioWindow() 
            elif activity_key=='radioDB':
                self.show_RadioDBWindow()
            #elif activity_key=='radioDeconv':
            #    self.show_RadioWindow()
            elif activity_key=='hline':
                self.show_HlineWindow() 
            elif activity_key=='securearea':
                print('ENTERING SECURE AREA')
                self.SecureArea() 
            elif activitykey_sa == 'home':
                self.RadioWindow.close()
                self.show_SelectWindow()
            else:
                self.show_RadioWindow()
    def show_RadioWindow(self):
        self.RadioWindow = RadioWindow()
        #self.KSWindow.switch_window.connect(self.show_InfoWindow)
        self.InfoWindow.close()
        self.RadioWindow.show()

    def show_RadioDBWindow(self):
        self.RadioWindow = RadioDBWindow()
        #self.KSWindow.switch_window.connect(self.show_InfoWindow)
        self.InfoWindow.close()
        self.RadioWindow.show()

    def show_HlineWindow(self):
        self.RadioWindow = HlineWindow()
        #self.KSWindow.switch_window.connect(self.show_InfoWindow)
        self.InfoWindow.close()
        self.RadioWindow.show()

    def StartFlight(self):
        self.Radiowindow = flightWindow()
     #   self.window.switch_window.connect(self.show_SelectWindow)
        self.InfoWindow.close()
        self.Radiowindow.show()

    def SecureArea(self):
        self.Radiowindow = LWindow()
     #   self.window.switch_window.connect(self.show_SelectWindow)
        self.window.close()
        self.Radiowindow.show()

def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(style)
    controller = Controller()
    controller.show_EnterRadeot()
    sys.exit(app.exec_())
    

if __name__ == '__main__':
    main()
    #  app = QApplication(sys.argv)