# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'InfoWindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_InfoWindow(object):
    def setupUi(self, InfoWindow):
        InfoWindow.setObjectName("InfoWindow")
        InfoWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(InfoWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.StartButton = QtWidgets.QPushButton(self.centralwidget)
        self.StartButton.setObjectName("StartButton")
        self.horizontalLayout.addWidget(self.StartButton)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.movie_screen = QtWidgets.QLabel(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(40)
        sizePolicy.setVerticalStretch(48)
        sizePolicy.setHeightForWidth(self.movie_screen.sizePolicy().hasHeightForWidth())
        self.movie_screen.setSizePolicy(sizePolicy)
        self.movie_screen.setAlignment(QtCore.Qt.AlignCenter)
        self.movie_screen.setObjectName("movie_screen")
        self.verticalLayout_2.addWidget(self.movie_screen)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.InfoText = QtWidgets.QTextEdit(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.InfoText.sizePolicy().hasHeightForWidth())
        self.InfoText.setSizePolicy(sizePolicy)
        self.InfoText.setSizeAdjustPolicy(QtWidgets.QAbstractScrollArea.AdjustToContents)
        self.InfoText.setObjectName("InfoText")
        self.verticalLayout.addWidget(self.InfoText)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout_2.addLayout(self.verticalLayout)
        self.verticalLayout_2.addLayout(self.horizontalLayout_2)
        InfoWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(InfoWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        InfoWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(InfoWindow)
        self.statusbar.setObjectName("statusbar")
        InfoWindow.setStatusBar(self.statusbar)

        self.retranslateUi(InfoWindow)
        QtCore.QMetaObject.connectSlotsByName(InfoWindow)

    def retranslateUi(self, InfoWindow):
        _translate = QtCore.QCoreApplication.translate
        InfoWindow.setWindowTitle(_translate("InfoWindow", "MainWindow"))
        self.StartButton.setText(_translate("InfoWindow", "[ Start ]"))
        self.movie_screen.setText(_translate("InfoWindow", "TextLabel"))
